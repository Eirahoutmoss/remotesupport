//go:build windows

package main

import (
	"bytes"
	"context"
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"image"
	"image/color"
	"image/jpeg"
	"image/png"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"

	"github.com/eirahoutmoss/remotesupport/client/capture"
	"github.com/eirahoutmoss/remotesupport/client/screen"
	clientsignaling "github.com/eirahoutmoss/remotesupport/client/signaling"
	webrtcpeer "github.com/eirahoutmoss/remotesupport/client/webrtc"
	server "github.com/eirahoutmoss/remotesupport/server/signaling"
	"github.com/eirahoutmoss/remotesupport/shared/protocol"
	"github.com/pion/webrtc/v4"
	"golang.org/x/sys/windows"
)

const (
	appTitle            = "NexDesk"
	defaultSignalingURL = ""
	windowClass         = "RemoteSupportWindow"
	viewerClass         = "RemoteSupportViewer"
	windowWidth         = 1180
	windowHeight        = 760

	ID_GET_SUPPORT    = 1001
	ID_GIVE_SUPPORT   = 1002
	ID_BACK           = 1003
	ID_COPY_CODE      = 1004
	ID_REMOTE_CODE    = 1005
	ID_CONNECT        = 1006
	ID_SETTINGS       = 1007
	ID_ABOUT          = 1008
	ID_SETTINGS_SAVE  = 1009
	ID_SETTINGS_RESET = 1010
	ID_MONITOR_BASE   = 2000
	ID_FILE_SEND      = 3001
	ID_RES_ORIGINAL   = 4000
	ID_RES_1080P      = 4001
	ID_RES_720P       = 4002
	ID_RES_480P       = 4003
	ID_FULLSCREEN     = 5001
	ID_ELEVATE        = 5002
	ID_CLIP_SEND      = 5003
	ID_CLIP_GET       = 5004
	ID_CHAT_SEND      = 5005
	ID_STAY_OPEN      = 5006
	ID_ACTIONS        = 5007
	ID_SHOT           = 5008
	ID_KEY_WIN        = 5009
	ID_KEY_ALTTAB     = 5010
	ID_KEY_ESC        = 5011
	ID_CURTAIN        = 5012
	ID_LOCKINPUT      = 5013
	ID_SYSINFO        = 5014
	ID_ANNOT          = 5015
	ID_SHARE_LINK     = 5016
	WM_APP_MONITORS   = 0x8001
	WM_APP_IDLE       = 0x8002
	WM_APP_IDLE_CLOSE = 0x8003
	WM_APP_CURTAIN    = 0x8004
	WM_APP_ANNOT      = 0x8005
)

var (
	gdi32DLL          = syscall.NewLazyDLL("gdi32.dll")
	comdlg32          = syscall.NewLazyDLL("comdlg32.dll")
	user32            = syscall.NewLazyDLL("user32.dll")
	kernel32          = syscall.NewLazyDLL("kernel32.dll")
	shell32           = syscall.NewLazyDLL("shell32.dll")
	shellExecuteW     = shell32.NewProc("ShellExecuteW")
	registerClass     = user32.NewProc("RegisterClassExW")
	createWindow      = user32.NewProc("CreateWindowExW")
	defWindowProc     = user32.NewProc("DefWindowProcW")
	showWindow        = user32.NewProc("ShowWindow")
	setWindowPos      = user32.NewProc("SetWindowPos")
	getWindowRect     = user32.NewProc("GetWindowRect")
	getWindowLongPtr  = user32.NewProc("GetWindowLongPtrW")
	setWindowLongPtr  = user32.NewProc("SetWindowLongPtrW")
	updateWindow      = user32.NewProc("UpdateWindow")
	getMessage        = user32.NewProc("GetMessageW")
	translateMsg      = user32.NewProc("TranslateMessage")
	dispatchMessage   = user32.NewProc("DispatchMessageW")
	postQuit          = user32.NewProc("PostQuitMessage")
	sendMessage       = user32.NewProc("SendMessageW")
	postMessage       = user32.NewProc("PostMessageW")
	setWindowText     = user32.NewProc("SetWindowTextW")
	getWindowText     = user32.NewProc("GetWindowTextW")
	destroyWindow     = user32.NewProc("DestroyWindow")
	messageBox        = user32.NewProc("MessageBoxW")
	getModule         = kernel32.NewProc("GetModuleHandleW")
	globalMemStatus   = kernel32.NewProc("GlobalMemoryStatusEx")
	getDiskFreeSpace  = kernel32.NewProc("GetDiskFreeSpaceExW")
	loadCursor        = user32.NewProc("LoadCursorW")
	loadImage         = user32.NewProc("LoadImageW")
	openClipboard     = user32.NewProc("OpenClipboard")
	emptyClipboard    = user32.NewProc("EmptyClipboard")
	setClipboardData  = user32.NewProc("SetClipboardData")
	closeClipboard    = user32.NewProc("CloseClipboard")
	beginPaint        = user32.NewProc("BeginPaint")
	endPaint          = user32.NewProc("EndPaint")
	fillRect          = user32.NewProc("FillRect")
	getClientRect     = user32.NewProc("GetClientRect")
	getCursorPos      = user32.NewProc("GetCursorPos")
	createPopupMenu   = user32.NewProc("CreatePopupMenu")
	appendMenuW       = user32.NewProc("AppendMenuW")
	trackPopupMenu    = user32.NewProc("TrackPopupMenu")
	destroyMenu       = user32.NewProc("DestroyMenu")
	setWinDisplayAff  = user32.NewProc("SetWindowDisplayAffinity")
	blockInput        = user32.NewProc("BlockInput")
	setLayeredWinAttr = user32.NewProc("SetLayeredWindowAttributes")
	screenToClient    = user32.NewProc("ScreenToClient")
	getSystemMetrics  = user32.NewProc("GetSystemMetrics")
	sendInput         = user32.NewProc("SendInput")
	setFocus          = user32.NewProc("SetFocus")
	invalidateRect    = user32.NewProc("InvalidateRect")
	registerClassEx   = user32.NewProc("RegisterClassExW")
	stretchDIBits     = gdi32DLL.NewProc("StretchDIBits")
	setStretchMode    = gdi32DLL.NewProc("SetStretchBltMode")
	getStockObject    = gdi32DLL.NewProc("GetStockObject")
	createPen         = gdi32DLL.NewProc("CreatePen")
	moveToEx          = gdi32DLL.NewProc("MoveToEx")
	lineTo            = gdi32DLL.NewProc("LineTo")
	selectObject      = gdi32DLL.NewProc("SelectObject")
	deleteObject      = gdi32DLL.NewProc("DeleteObject")
	roundRect         = gdi32DLL.NewProc("RoundRect")
	drawText          = user32.NewProc("DrawTextW")
	mapVirtualKey     = user32.NewProc("MapVirtualKeyW")
	createFont        = gdi32DLL.NewProc("CreateFontW")
	createSolidBrush  = gdi32DLL.NewProc("CreateSolidBrush")
	setTextColor      = gdi32DLL.NewProc("SetTextColor")
	setBkColor        = gdi32DLL.NewProc("SetBkColor")
	setBkMode         = gdi32DLL.NewProc("SetBkMode")
	patBlt            = gdi32DLL.NewProc("PatBlt")
	ellipse           = gdi32DLL.NewProc("Ellipse")
	setCapture        = user32.NewProc("SetCapture")
	releaseCapture    = user32.NewProc("ReleaseCapture")
	globalAlloc       = kernel32.NewProc("GlobalAlloc")
	globalLock        = kernel32.NewProc("GlobalLock")
	globalUnlock      = kernel32.NewProc("GlobalUnlock")
	getOpenFileName   = comdlg32.NewProc("GetOpenFileNameW")
	isDialogMessage   = user32.NewProc("IsDialogMessageW")
	commDlgError      = comdlg32.NewProc("CommDlgExtendedError")
	messageBeep       = user32.NewProc("MessageBeep")
	flashWindow       = user32.NewProc("FlashWindow")
	callWindowProc    = user32.NewProc("CallWindowProcW")
)

type point struct{ X, Y int32 }
type openFileName struct {
	StructSize    uint32
	Owner         uintptr
	Instance      uintptr
	Filter        *uint16
	CustomFilter  *uint16
	MaxCustFilter uint32
	FilterIndex   uint32
	File          *uint16
	MaxFile       uint32
	FileTitle     *uint16
	MaxFileTitle  uint32
	InitialDir    *uint16
	Title         *uint16
	Flags         uint32
	FileOffset    uint16
	FileExtension uint16
	DefExt        *uint16
	CustData      uintptr
	Hook          uintptr
	TemplateName  *uint16
	Reserved      uintptr
	Reserved2     uint32
	FlagsEx       uint32
}

type fileReceiveState struct {
	mu       sync.Mutex
	file     *os.File
	name     string
	total    int64
	received int64
	tempPath string
}

var fileRx fileReceiveState
var fileSendMu sync.Mutex

type rect struct{ Left, Top, Right, Bottom int32 }
type wndclassex struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type msg struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      point
}
type windowState struct {
	hwnd               uintptr
	mode               int
	status             uintptr
	codeLabel          uintptr
	codeEdit           uintptr
	remoteEdit         uintptr
	monitorButtons     []uintptr
	action             uintptr
	copy               uintptr
	back               uintptr
	homeGet            uintptr
	homeGive           uintptr
	fileSend           uintptr
	resolutionButtons  []uintptr
	fullscreenButton   uintptr
	elevate            uintptr
	clipSend           uintptr
	clipGet            uintptr
	chatInput          uintptr
	chatSend           uintptr
	settingsEndpoint   uintptr
	settingsQuality    uintptr
	settingsResolution uintptr
	settingsSave       uintptr
	settingsReset      uintptr
	settingsIdle       uintptr
	settingsIdleAction uintptr
	settingsTurnURL    uintptr
	settingsTurnUser   uintptr
	settingsTurnPass   uintptr
	stayOpen           uintptr
	actionsBtn         uintptr
	shareLink          uintptr
	header             uintptr
	subtitle           uintptr
	statusText         string

	mu     sync.Mutex
	sig    *clientsignaling.Client
	peer   *webrtcpeer.Peer
	cancel context.CancelFunc
	ctx    context.Context
}

var state windowState

var viewer viewerState

var (
	uiBgBrush      uintptr
	uiPanelBrush   uintptr
	uiEditBrush    uintptr
	uiHeaderFont   uintptr
	uiBrandFont    uintptr
	uiTitleFont    uintptr
	uiSubtitleFont uintptr
	uiBodyFont     uintptr
	uiButtonFont   uintptr
	uiLabelFont    uintptr
	uiSmallFont    uintptr
	uiCodeFont     uintptr
	uiEditFont     uintptr
	uiIconFont     uintptr
)

// Palette. Values are written as intuitive 0xRRGGBB and converted to the
// Win32 COLORREF byte order (0x00BBGGRR) by rgb() at every use site. Writing
// them as RGB and passing them straight to GDI (as the first version did) makes
// GDI read them as BGR, which turned the blue accent orange and the navy canvas
// brown; rgb() is what actually gives the concept its blue/navy look.
const (
	uiBgColor     = 0x0A1220 // app canvas, deep navy (top of gradient)
	uiBgColor2    = 0x0C1626 // app canvas, bottom of gradient
	uiBarColor    = 0x0B1524 // top product bar + footer
	uiNavColor    = 0x080F1C // left navigation rail (darkest surface)
	uiPanelColor  = 0x131F30 // cards / panels
	uiPanelHi     = 0x182842 // hovered / active panel
	uiEditColor   = 0x070C16 // input fields, code box (darker for contrast)
	uiBorderColor = 0x21324B // hairline dividers / borders
	uiTextColor   = 0xEDF2F8 // primary text
	uiMutedColor  = 0x93A4BA // secondary text
	uiFaintColor  = 0x5D6E85 // tertiary / placeholder text
	uiAccentColor = 0x2E90FF // primary accent (blue)
	uiAccentHi    = 0x57A9FF // accent highlight (gradient top / glow)
	uiAccentDim   = 0x1E5FB0 // accent shadow (gradient bottom)
	uiCyanColor   = 0x38BDF8 // secondary accent used sparingly on icons
	uiSuccess     = 0x26D07C // "connected" / live status
	uiDanger      = 0xEF4655 // disconnect / destructive
	uiDangerHi    = 0xF56672 // disconnect highlight
	uiWarn        = 0xF5A623 // caution (medium link quality)
)

type appSettings struct {
	SignalingURL string `json:"signaling_url"`
	Quality      int    `json:"quality"`
	MaxHeight    int    `json:"max_height"`
	InputEnabled bool   `json:"input_enabled"`
	IdleWarnMin  int    `json:"idle_warn_min"`
	IdleClose    bool   `json:"idle_close"`
	TurnURL      string `json:"turn_url"`
	TurnUser     string `json:"turn_user"`
	TurnPass     string `json:"turn_pass"`
}

var settingsMu sync.RWMutex
var appCfg = appSettings{Quality: 88, MaxHeight: 0, InputEnabled: true, IdleWarnMin: 10, IdleClose: false}

func settingsPath() string {
	base, err := os.UserConfigDir()
	if err != nil || base == "" {
		return ""
	}
	dir := filepath.Join(base, "RemoteSupport")
	_ = os.MkdirAll(dir, 0700)
	return filepath.Join(dir, "settings.json")
}

func loadSettings() {
	path := settingsPath()
	if path == "" {
		return
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return
	}
	var cfg appSettings
	if json.Unmarshal(b, &cfg) != nil {
		return
	}
	if cfg.Quality != 76 && cfg.Quality != 88 {
		cfg.Quality = 88
	}
	if cfg.MaxHeight != 0 && cfg.MaxHeight != 1080 && cfg.MaxHeight != 720 && cfg.MaxHeight != 480 {
		cfg.MaxHeight = 0
	}
	if cfg.IdleWarnMin != 0 && cfg.IdleWarnMin != 10 && cfg.IdleWarnMin != 20 && cfg.IdleWarnMin != 30 {
		cfg.IdleWarnMin = 10
	}
	settingsMu.Lock()
	appCfg = cfg
	settingsMu.Unlock()
}

func saveSettings() {
	path := settingsPath()
	if path == "" {
		return
	}
	settingsMu.RLock()
	cfg := appCfg
	settingsMu.RUnlock()
	b, _ := json.MarshalIndent(cfg, "", "  ")
	_ = os.WriteFile(path, b, 0600)
}

func currentSettings() appSettings { settingsMu.RLock(); defer settingsMu.RUnlock(); return appCfg }

var targetMonitorCache struct {
	sync.Once
	monitor capture.Monitor
	ok      bool
}

var sameHostPeer atomic.Bool
var embeddedSignalingReady atomic.Bool
var sidebarPage atomic.Int32
var activeMonitor atomic.Int32

// Live session telemetry, all read from the paint thread and written from
// worker goroutines, so every field is atomic or mutex-guarded.
var sessionStartUnix atomic.Int64 // connect time (unix nanos); 0 = not connected
var framesRecv atomic.Uint64      // total frames the operator has rendered
var fpsValue atomic.Int32         // frames/second, refreshed once per second
var capturing atomic.Bool         // agent is actively streaming its own screen
var lastActivityUnix atomic.Int64 // last remote-control input (either side)
var idleWarn atomic.Bool          // idle warning currently shown
var curtainHwnd uintptr           // agent-side privacy curtain window
var remoteCurtainOn atomic.Bool   // operator: curtain toggle state
var remoteLockOn atomic.Bool      // operator: input-lock toggle state
var remoteHostMu sync.Mutex
var remoteHostName string

func setRemoteHost(h string) { remoteHostMu.Lock(); remoteHostName = h; remoteHostMu.Unlock() }
func getRemoteHost() string  { remoteHostMu.Lock(); defer remoteHostMu.Unlock(); return remoteHostName }

var connInfoMu sync.Mutex
var connPathStr string // "direct" / "relay" / ""
var sasStr string      // 6-digit SAS once known
var activeCodeStr string

func setActiveCode(code string) {
	connInfoMu.Lock()
	activeCodeStr = strings.ReplaceAll(strings.TrimSpace(code), " ", "")
	connInfoMu.Unlock()
}

func getActiveCode() string {
	connInfoMu.Lock()
	defer connInfoMu.Unlock()
	return activeCodeStr
}

func setConnInfo(path, sas string) {
	connInfoMu.Lock()
	if path != "" {
		connPathStr = path
	}
	if sas != "" {
		sasStr = sas
	}
	connInfoMu.Unlock()
}

func getConnInfo() (string, string) {
	connInfoMu.Lock()
	defer connInfoMu.Unlock()
	return connPathStr, sasStr
}

func resetConnInfo() {
	connInfoMu.Lock()
	connPathStr, sasStr = "", ""
	connInfoMu.Unlock()
	sessionStartUnix.Store(0)
	framesRecv.Store(0)
	fpsValue.Store(0)
	capturing.Store(false)
	idleWarn.Store(false)
}

func isElevated() bool {
	return windows.GetCurrentProcessToken().IsElevated()
}

// restartAsAdmin relaunches this executable through the standard UAC prompt
// (ShellExecute "runas"). It never bypasses UAC; the user still consents.
func restartAsAdmin() {
	exe, err := os.Executable()
	if err != nil {
		setStatus("● Yönetici olarak başlatılamadı: " + err.Error())
		return
	}
	verb := utf16ptr("runas")
	file := utf16ptr(exe)
	r, _, _ := shellExecuteW.Call(0, uintptr(unsafe.Pointer(verb)), uintptr(unsafe.Pointer(file)), 0, 0, 1) // SW_SHOWNORMAL
	if r <= 32 {
		// User declined the prompt or it failed; stay running unelevated.
		setStatus("● Yükseltme iptal edildi.")
		return
	}
	postQuit.Call(0) // elevated instance is starting; close this one
}

// sessionElapsed formats the live session duration as MM:SS.
func sessionElapsed() string {
	start := sessionStartUnix.Load()
	if start == 0 {
		return "00:00"
	}
	d := time.Since(time.Unix(0, start))
	if d < 0 {
		d = 0
	}
	total := int(d.Seconds())
	return fmt.Sprintf("%02d:%02d", total/60, total%60)
}

// startSessionStats refreshes FPS, path and SAS once per second while the
// session is live, then repaints the shell so the stat strip stays current.
func startSessionStats(peer *webrtcpeer.Peer) {
	sessionStartUnix.Store(time.Now().UnixNano())
	lastActivityUnix.Store(time.Now().Unix())
	framesRecv.Store(0)
	go func() {
		defer logCrash("sessionStats")
		var last uint64
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			if sessionStartUnix.Load() == 0 || peerDead(peer) {
				return
			}
			now := framesRecv.Load()
			fpsValue.Store(int32(now - last))
			last = now
			if path := peer.PathKind(); path != "" {
				setConnInfo(path, "")
			}
			if _, sas := getConnInfo(); sas == "" {
				if v, ok := peer.FingerprintSAS(getActiveCode()); ok {
					setConnInfo("", v)
				}
			}
			cfg := currentSettings()
			if cfg.IdleWarnMin > 0 {
				idle := time.Now().Unix() - lastActivityUnix.Load()
				warnAt := int64(cfg.IdleWarnMin) * 60
				if idle >= warnAt {
					if !idleWarn.Swap(true) && state.hwnd != 0 {
						postMessage.Call(state.hwnd, WM_APP_IDLE, 0, 0)
					}
					if cfg.IdleClose && idle >= warnAt+60 && state.hwnd != 0 {
						postMessage.Call(state.hwnd, WM_APP_IDLE_CLOSE, 0, 0)
						return
					}
				} else if idleWarn.Swap(false) && state.hwnd != 0 {
					postMessage.Call(state.hwnd, WM_APP_IDLE, 0, 0)
				}
			}
			if state.hwnd != 0 {
				invalidateRect.Call(state.hwnd, 0, 0)
			}
		}
	}()
}

var remoteMonitorsMu sync.RWMutex
var remoteMonitors []capture.Monitor

var activeTargetMonitorMu sync.RWMutex
var activeTargetMonitor capture.Monitor
var activeTargetMonitorOK bool

var captureMaxHeight atomic.Int32
var fullscreen atomic.Bool
var fullscreenSavedStyle uintptr
var fullscreenSavedRect rect
var fullscreenSavedValid bool

type viewerState struct {
	hwnd   uintptr
	active bool
	mu     sync.RWMutex
	pixels []byte
	width  int
	height int
	seq    uint64

	// Fit is the default remote-desktop view. When zoomed, panX/panY are
	// the image's top-left corner in viewer-client coordinates.
	fit         bool
	zoom        float64
	panX        float64
	panY        float64
	dragging    bool
	clearNeeded bool
	dragX       int
	dragY       int
	lastMoveAt  time.Time
}

type winMouseInput struct {
	Dx, Dy      int32
	MouseData   uint32
	DwFlags     uint32
	Time        uint32
	DwExtraInfo uintptr
}

type winKeyboardInput struct {
	Vk          uint16
	Scan        uint16
	Flags       uint32
	Time        uint32
	DwExtraInfo uintptr
}

type winInput struct {
	Type uint32
	Pad  uint32
	Mi   winMouseInput
}

type winKeyInput struct {
	Type uint32
	Pad  uint32
	Ki   winKeyboardInput
	Pad2 [8]byte // INPUT union is 32 bytes on Windows x64
}

const (
	inputMouse    = 0
	inputKeyboard = 1

	mouseMove       = 0x0001
	mouseLeftDown   = 0x0002
	mouseLeftUp     = 0x0004
	mouseRightDown  = 0x0008
	mouseRightUp    = 0x0010
	mouseMiddleDown = 0x0020
	mouseMiddleUp   = 0x0040
	mouseWheel      = 0x0800
	mouseAbsolute   = 0x8000
	mouseVirtual    = 0x4000

	keyUp       = 0x0002
	keyScancode = 0x0008
	keyExtended = 0x0001
)

type bitmapInfoHeader struct {
	BiSize          uint32
	BiWidth         int32
	BiHeight        int32
	BiPlanes        uint16
	BiBitCount      uint16
	BiCompression   uint32
	BiSizeImage     uint32
	BiXPelsPerMeter int32
	BiYPelsPerMeter int32
	BiClrUsed       uint32
	BiClrImportant  uint32
}
type bitmapInfo struct {
	BmiHeader bitmapInfoHeader
	BmiColors [3]uint32
}

type memoryStatusEx struct {
	Length               uint32
	MemoryLoad           uint32
	TotalPhys            uint64
	AvailPhys            uint64
	TotalPageFile        uint64
	AvailPageFile        uint64
	TotalVirtual         uint64
	AvailVirtual         uint64
	AvailExtendedVirtual uint64
}

type paintStruct struct {
	hdc         uintptr
	erase       int32
	rcPaint     rect
	restore     int32
	incUpdate   int32
	rgbReserved [32]byte
}

func utf16ptr(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

// rgb converts an intuitive 0xRRGGBB value to a Win32 COLORREF (0x00BBGGRR),
// which is the byte order GDI's CreateSolidBrush / SetTextColor expect.
func rgb(hex uint32) uintptr {
	r := (hex >> 16) & 0xFF
	g := (hex >> 8) & 0xFF
	b := hex & 0xFF
	return uintptr(b<<16 | g<<8 | r)
}

// mix blends two 0xRRGGBB colors by t in [0,1] and returns a COLORREF. Used for
// cheap vertical gradients (bands) and glow falloff without alpha blending.
func mix(a, b uint32, t float64) uintptr {
	if t < 0 {
		t = 0
	}
	if t > 1 {
		t = 1
	}
	ar, ag, ab := (a>>16)&0xFF, (a>>8)&0xFF, a&0xFF
	br, bg, bb := (b>>16)&0xFF, (b>>8)&0xFF, b&0xFF
	r := uint32(float64(ar) + (float64(br)-float64(ar))*t)
	g := uint32(float64(ag) + (float64(bg)-float64(ag))*t)
	bl := uint32(float64(ab) + (float64(bb)-float64(ab))*t)
	return uintptr(bl<<16 | g<<8 | r)
}

// fillBand paints a solid rectangle in a COLORREF (already byte-ordered).
func fillBand(hdc uintptr, x, y, w, h int, color uintptr) {
	if w <= 0 || h <= 0 {
		return
	}
	rc := rect{Left: int32(x), Top: int32(y), Right: int32(x + w), Bottom: int32(y + h)}
	brush, _, _ := createSolidBrush.Call(color)
	if brush != 0 {
		fillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), brush)
		deleteObject.Call(brush)
	}
}

// vGradient paints a vertical gradient from 0xRRGGBB top to bottom using n bands.
func vGradient(hdc uintptr, x, y, w, h int, top, bottom uint32, n int) {
	if h <= 0 || w <= 0 {
		return
	}
	if n < 1 {
		n = 1
	}
	step := float64(h) / float64(n)
	for i := 0; i < n; i++ {
		by := y + int(float64(i)*step)
		bh := y + int(float64(i+1)*step) - by
		if bh < 1 {
			bh = 1
		}
		fillBand(hdc, x, by, w, bh, mix(top, bottom, float64(i)/float64(n-1+1)))
	}
}

func makeUIFont(height int, weight int) uintptr {
	face := utf16ptr("Segoe UI")
	r, _, _ := createFont.Call(
		uintptr(int32(-height)), 0, 0, 0, uintptr(weight), 0, 0, 0,
		uintptr(1), 0, 0, 5, 0, uintptr(unsafe.Pointer(face)),
	)
	return r
}

func initUITheme() {
	uiBgBrush, _, _ = createSolidBrush.Call(rgb(uiBgColor))
	uiPanelBrush, _, _ = createSolidBrush.Call(rgb(uiPanelColor))
	uiEditBrush, _, _ = createSolidBrush.Call(rgb(uiEditColor))
	uiHeaderFont = makeUIFont(27, 700)   // page titles ("Uzaktan Destek")
	uiBrandFont = makeUIFont(20, 800)    // product wordmark
	uiTitleFont = makeUIFont(18, 700)    // card titles
	uiSubtitleFont = makeUIFont(15, 600) // section / row titles
	uiBodyFont = makeUIFont(13, 400)     // body text
	uiButtonFont = makeUIFont(13, 600)   // button labels
	uiLabelFont = makeUIFont(11, 700)    // ALL-CAPS section labels
	uiSmallFont = makeUIFont(11, 400)    // stats / captions
	uiCodeFont = makeUIFont(36, 800)     // big connection code
	uiEditFont = makeUIFont(22, 600)     // input fields
	uiIconFont = makeUIFont(20, 400)     // glyph icons
}

func setControlFont(hwnd, font uintptr) {
	if hwnd != 0 && font != 0 {
		sendMessage.Call(hwnd, 0x0030, font, 1) // WM_SETFONT
	}
}

func registerViewerClass() {
	class := utf16ptr(viewerClass)
	wc := wndclassex{
		CbSize:        uint32(unsafe.Sizeof(wndclassex{})),
		LpfnWndProc:   syscall.NewCallback(viewerWndProc),
		HInstance:     moduleHandle(),
		HCursor:       func() uintptr { r, _, _ := loadCursor.Call(0, 32512); return r }(),
		HbrBackground: 4, // BLACK_BRUSH
		LpszClassName: class,
		HIcon:         appIcon(32),
		HIconSm:       appIcon(16),
	}
	registerClassEx.Call(uintptr(unsafe.Pointer(&wc)))
}

func createViewer(parent uintptr) uintptr {
	class := utf16ptr(viewerClass)
	hwnd, _, _ := createWindow.Call(
		0,
		uintptr(unsafe.Pointer(class)),
		0,
		0x40000000|0x10000000|0x00800000, // WS_CHILD | WS_VISIBLE | WS_BORDER
		20, 120, 720, 400,
		parent, 0, moduleHandle(), 0,
	)
	viewer.hwnd = hwnd
	viewer.mu.Lock()
	viewer.fit = true
	viewer.zoom = 1
	viewer.mu.Unlock()
	return hwnd
}

func resizeViewer() {
	h := viewer.hwnd
	if h == 0 || state.hwnd == 0 {
		return
	}
	var rc rect
	getClientRect.Call(state.hwnd, uintptr(unsafe.Pointer(&rc)))
	w := int(rc.Right - rc.Left)
	ht := int(rc.Bottom - rc.Top)
	if w < 1 || ht < 1 {
		return
	}

	viewer.mu.RLock()
	active := viewer.active
	viewer.mu.RUnlock()
	if active && !fullscreen.Load() {
		cg := computeChatGeom(w, ht)
		vw := w - 190
		if cg.visible {
			vw = cg.x - 168 - 12
		}
		setWindowPos.Call(h, 0, 168, 145, uintptr(maxInt(1, vw)), uintptr(maxInt(1, ht-210)), 0x0004|0x0010)
	} else if active {
		setWindowPos.Call(h, 0, 0, 86, uintptr(maxInt(1, w)), uintptr(maxInt(1, ht-86)), 0x0004|0x0010)
	}
}

func toggleFullscreen() {
	if state.hwnd == 0 {
		return
	}
	if fullscreen.Load() {
		if fullscreenSavedValid {
			setWindowLongPtr.Call(state.hwnd, ^uintptr(15), fullscreenSavedStyle)
			w := int(fullscreenSavedRect.Right - fullscreenSavedRect.Left)
			h := int(fullscreenSavedRect.Bottom - fullscreenSavedRect.Top)
			setWindowPos.Call(state.hwnd, 0, uintptr(fullscreenSavedRect.Left), uintptr(fullscreenSavedRect.Top), uintptr(maxInt(1, w)), uintptr(maxInt(1, h)), 0x0004|0x0020|0x0040)
		}
		fullscreen.Store(false)
		show(state.fullscreenButton)
		showResolutionControls(true)
		showMonitorControls(true)
	} else {
		var rc rect
		getWindowRect.Call(state.hwnd, uintptr(unsafe.Pointer(&rc)))
		style, _, _ := getWindowLongPtr.Call(state.hwnd, ^uintptr(15))
		fullscreenSavedStyle = style
		fullscreenSavedRect = rc
		fullscreenSavedValid = true
		setWindowLongPtr.Call(state.hwnd, ^uintptr(15), 0x80000000|0x10000000)
		cx := systemMetric(0)
		cy := systemMetric(1)
		setWindowPos.Call(state.hwnd, 0, 0, 0, uintptr(maxInt(1, int(cx))), uintptr(maxInt(1, int(cy))), 0x0004|0x0020|0x0040)
		fullscreen.Store(true)
		hide(state.fullscreenButton)
		showResolutionControls(false)
		showMonitorControls(false)
	}
	layoutUI()
	resizeViewer()
	invalidateRect.Call(viewer.hwnd, 0, 0)
}

func showResolutionControls(visible bool) {
	state.mu.Lock()
	buttons := append([]uintptr(nil), state.resolutionButtons...)
	state.mu.Unlock()
	for _, h := range buttons {
		if visible {
			show(h)
		} else {
			hide(h)
		}
	}
}

func showMonitorControls(visible bool) {
	state.mu.Lock()
	buttons := append([]uintptr(nil), state.monitorButtons...)
	state.mu.Unlock()
	for _, h := range buttons {
		if visible {
			show(h)
		} else {
			hide(h)
		}
	}
}

func setRemoteResolution(maxHeight int) {
	if maxHeight < 0 {
		maxHeight = 0
	}
	state.mu.Lock()
	peer := state.peer
	state.mu.Unlock()
	if peer != nil {
		_ = peer.SendControlText(fmt.Sprintf("RESOLUTION:%d", maxHeight))
	}
	labels := map[int]string{0: "Otomatik", 1080: "1080p", 720: "720p", 480: "480p"}
	if label, ok := labels[maxHeight]; ok {
		setStatus("● Görüntü çözünürlüğü: " + label)
	}
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func saveViewerScreenshot() {
	viewer.mu.RLock()
	w, h := viewer.width, viewer.height
	px := viewer.pixels
	viewer.mu.RUnlock()
	if w <= 0 || h <= 0 || len(px) < w*h*4 {
		setStatus("● Ekran görüntüsü alınamadı: görüntü yok.")
		return
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for i := 0; i < w*h; i++ {
		img.Pix[i*4+0] = px[i*4+2] // R (frame is BGRA)
		img.Pix[i*4+1] = px[i*4+1] // G
		img.Pix[i*4+2] = px[i*4+0] // B
		img.Pix[i*4+3] = 255
	}
	home, err := os.UserHomeDir()
	if err != nil {
		setStatus("● Ekran görüntüsü kaydedilemedi.")
		return
	}
	dir := filepath.Join(home, "Downloads")
	_ = os.MkdirAll(dir, 0755)
	path := filepath.Join(dir, fmt.Sprintf("RemoteSupport-%s.jpg", time.Now().Format("20060102-150405")))
	f, err := os.Create(path)
	if err != nil {
		setStatus("● Ekran görüntüsü kaydedilemedi: " + err.Error())
		return
	}
	defer f.Close()
	if err := jpeg.Encode(f, img, &jpeg.Options{Quality: 90}); err != nil {
		setStatus("● Ekran görüntüsü kodlanamadı.")
		return
	}
	setStatus("● Ekran görüntüsü kaydedildi: " + path)
}

func setViewerFrame(f screen.Frame) {
	img, err := jpeg.Decode(bytes.NewReader(f.JPEG))
	if err != nil {
		return
	}
	bounds := img.Bounds()
	width, height := bounds.Dx(), bounds.Dy()
	pixels := make([]byte, width*height*4)

	// image/jpeg normally decodes into *image.YCbCr. Avoid img.At(), which
	// performs interface/color-model work for every pixel and became a major
	// CPU/GC cost at 3440x1440. Read the Y/Cb/Cr planes directly instead.
	if ycc, ok := img.(*image.YCbCr); ok && bounds.Min.X == 0 && bounds.Min.Y == 0 {
		ratio := ycc.SubsampleRatio
		for y := 0; y < height; y++ {
			yOff := y * ycc.YStride
			for x := 0; x < width; x++ {
				var cx, cy int
				switch ratio {
				case image.YCbCrSubsampleRatio444:
					cx, cy = x, y
				case image.YCbCrSubsampleRatio422:
					cx, cy = x/2, y
				case image.YCbCrSubsampleRatio440:
					cx, cy = x, y/2
				default: // 4:2:0, the common JPEG case
					cx, cy = x/2, y/2
				}
				cOff := cy*ycc.CStride + cx
				r, g, b := color.YCbCrToRGB(ycc.Y[yOff+x], ycc.Cb[cOff], ycc.Cr[cOff])
				i := (y*width + x) * 4
				pixels[i+0] = b
				pixels[i+1] = g
				pixels[i+2] = r
				pixels[i+3] = 0
			}
		}
	} else {
		for y := 0; y < height; y++ {
			for x := 0; x < width; x++ {
				r, g, b, _ := img.At(bounds.Min.X+x, bounds.Min.Y+y).RGBA()
				i := (y*width + x) * 4
				pixels[i+0] = byte(b >> 8)
				pixels[i+1] = byte(g >> 8)
				pixels[i+2] = byte(r >> 8)
			}
		}
	}

	viewer.mu.Lock()
	viewer.pixels = pixels
	viewer.width = width
	viewer.height = height
	viewer.seq = f.Seq
	h := viewer.hwnd
	viewer.mu.Unlock()
	framesRecv.Add(1)
	if h != 0 {
		invalidateRect.Call(h, 0, 0)
	}
}

func showViewer() {
	state.mu.Lock()
	buttons := append([]uintptr(nil), state.monitorButtons...)
	state.mu.Unlock()
	for _, h := range buttons {
		show(h)
	}
	viewer.mu.Lock()
	viewer.active = true
	viewer.fit = true
	viewer.zoom = 1
	viewer.panX = 0
	viewer.panY = 0
	viewer.clearNeeded = true
	h := viewer.hwnd
	viewer.mu.Unlock()
	if h != 0 {
		show(h)
	}
	showMonitorControls(!fullscreen.Load())
	showResolutionControls(!fullscreen.Load())
	show(state.fullscreenButton)
	resizeViewer()
}

func hideViewer() {
	if fullscreen.Load() {
		toggleFullscreen()
	}
	hide(state.fileSend)
	hide(state.fullscreenButton)
	showResolutionControls(false)
	showMonitorControls(false)
	state.mu.Lock()
	buttons := append([]uintptr(nil), state.monitorButtons...)
	state.mu.Unlock()
	for _, h := range buttons {
		hide(h)
	}
	viewer.mu.Lock()
	viewer.active = false
	h := viewer.hwnd
	viewer.mu.Unlock()
	if h != 0 {
		hide(h)
	}
}

func fitRect(srcW, srcH, dstW, dstH int) (left, top, width, height int) {
	if srcW <= 0 || srcH <= 0 || dstW <= 0 || dstH <= 0 {
		return 0, 0, dstW, dstH
	}
	// Compare ratios without floating point.
	if srcW*dstH >= srcH*dstW {
		width = dstW
		height = maxInt(1, srcH*dstW/srcW)
	} else {
		height = dstH
		width = maxInt(1, srcW*dstH/srcH)
	}
	left = (dstW - width) / 2
	top = (dstH - height) / 2
	return
}

func viewerWndProc(hwnd uintptr, m uint32, wParam, lParam uintptr) uintptr {
	switch m {
	case 0x0014: // WM_ERASEBKGND
		// Suppress background erase. WM_ERASEBKGND between frames is another
		// source of visible flashing; WM_PAINT draws the changed frame itself.
		return 1
	case 0x000F: // WM_PAINT
		var ps paintStruct
		hdc, _, _ := beginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		viewer.mu.Lock()
		pixels := viewer.pixels // immutable after publication; setViewerFrame replaces the slice.
		width, height := viewer.width, viewer.height
		fit, zoom, panX, panY := viewer.fit, viewer.zoom, viewer.panX, viewer.panY
		clearNeeded := viewer.clearNeeded
		viewer.clearNeeded = false
		viewer.mu.Unlock()
		if hdc != 0 {
			var rc rect
			getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
			dw := int(rc.Right - rc.Left)
			dh := int(rc.Bottom - rc.Top)
			// Clear only when the viewer geometry changes. Frame arrivals invalidate
			// the same window, but must not clear the existing image first.
			// That preserves the no-flicker behavior while keeping letterbox areas black.
			if clearNeeded {
				blackBrush, _, _ := getStockObject.Call(4) // BLACK_BRUSH
				if blackBrush != 0 {
					fillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), blackBrush)
				}
			}
			if len(pixels) == 0 {
				setBkMode.Call(hdc, 1)
				setTextColor.Call(hdc, rgb(uiMutedColor))
				oldf, _, _ := selectObject.Call(hdc, uiBodyFont)
				wt := utf16ptr("Bağlanıldı — ekran görüntüsü bekleniyor…")
				drawText.Call(hdc, uintptr(unsafe.Pointer(wt)), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(dtCenter|dtVCenter|dtSingleLine))
				selectObject.Call(hdc, oldf)
			}
			if len(pixels) > 0 && width > 0 && height > 0 && dw > 0 && dh > 0 {
				var left, top, drawW, drawH int
				if fit {
					left, top, drawW, drawH = fitRect(width, height, dw, dh)
				} else {
					drawW = maxInt(1, int(math.Round(float64(width)*zoom)))
					drawH = maxInt(1, int(math.Round(float64(height)*zoom)))
					left = int(math.Round(panX))
					top = int(math.Round(panY))
				}
				bi := bitmapInfo{BmiHeader: bitmapInfoHeader{
					BiSize:        uint32(unsafe.Sizeof(bitmapInfoHeader{})),
					BiWidth:       int32(width),
					BiHeight:      -int32(height),
					BiPlanes:      1,
					BiBitCount:    32,
					BiCompression: 0,
				}}
				setStretchMode.Call(hdc, 3) // COLORONCOLOR: materially faster for live remote desktop
				stretchDIBits.Call(hdc,
					uintptr(left), uintptr(top), uintptr(drawW), uintptr(drawH),
					0, 0, uintptr(width), uintptr(height),
					uintptr(unsafe.Pointer(&pixels[0])), uintptr(unsafe.Pointer(&bi)), 0, 0x00CC0020)
			}
			endPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		}
		return 0
	case 0x0005: // WM_SIZE
		viewer.mu.Lock()
		viewer.clearNeeded = true
		viewer.mu.Unlock()
		invalidateRect.Call(hwnd, 0, 0)
		return 0
	case 0x0007: // WM_SETFOCUS
		return 0
	case 0x0087: // WM_GETDLGCODE
		return 0x0004 | 0x0080 | 0x0001 | 0x0002 | 0x0004
	case 0x0201: // WM_LBUTTONDOWN
		setFocus.Call(hwnd)
		setCapture.Call(hwnd)
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		if annotateMode.Load() {
			if ax, ay, ok := normalizedViewerPoint(mx, my); ok {
				annotLastX, annotLastY, annotDrawing = ax, ay, true
			}
			return 0
		}
		sendRemoteMouse("down", mx, my, 0, 0)
		return 0
	case 0x0202: // WM_LBUTTONUP
		releaseCapture.Call()
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		if annotateMode.Load() {
			annotDrawing = false
			return 0
		}
		sendRemoteMouse("up", mx, my, 0, 0)
		return 0
	case 0x0204: // WM_RBUTTONDOWN
		setFocus.Call(hwnd)
		setCapture.Call(hwnd)
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		sendRemoteMouse("down", mx, my, 2, 0)
		return 0
	case 0x0205: // WM_RBUTTONUP
		releaseCapture.Call()
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		sendRemoteMouse("up", mx, my, 2, 0)
		return 0
	case 0x0207: // WM_MBUTTONDOWN
		setFocus.Call(hwnd)
		setCapture.Call(hwnd)
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		sendRemoteMouse("down", mx, my, 1, 0)
		return 0
	case 0x0208: // WM_MBUTTONUP
		releaseCapture.Call()
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		sendRemoteMouse("up", mx, my, 1, 0)
		return 0
	case 0x0100: // WM_KEYDOWN
		if wParam == 0x7A { // VK_F11
			toggleFullscreen()
			return 0
		}
		if wParam == 0x1B && fullscreen.Load() { // VK_ESCAPE
			toggleFullscreen()
			return 0
		}
		if wParam == 0x7B { // VK_F12: local screenshot, do not forward
			go saveViewerScreenshot()
			return 0
		}
		if wParam != 0 {
			sendRemoteKey("keydown", uint16(wParam))
		}
		return 0
	case 0x0101: // WM_KEYUP
		if wParam != 0 {
			sendRemoteKey("keyup", uint16(wParam))
		}
		return 0
	case 0x0104: // WM_SYSKEYDOWN (Alt, F-keys, etc.)
		if wParam != 0 {
			sendRemoteKey("keydown", uint16(wParam))
		}
		return 0
	case 0x0105: // WM_SYSKEYUP
		if wParam != 0 {
			sendRemoteKey("keyup", uint16(wParam))
		}
		return 0
	case 0x020A: // WM_MOUSEWHEEL
		delta := int16(uint16(wParam >> 16))
		if delta == 0 {
			return 0
		}
		var cursor point
		getCursorPos.Call(uintptr(unsafe.Pointer(&cursor)))
		screenToClient.Call(hwnd, uintptr(unsafe.Pointer(&cursor)))
		mx, my := int(cursor.X), int(cursor.Y)

		// The viewer is a remote desktop, not a camera. Every wheel event
		// goes to the remote computer. It must never zoom the local viewer.
		sendRemoteMouse("wheel", mx, my, 0, int(delta))
		return 0
	case 0x0200: // WM_MOUSEMOVE
		mx := int(int16(uint16(lParam & 0xffff)))
		my := int(int16(uint16(lParam >> 16)))
		if annotateMode.Load() {
			if annotDrawing {
				if ax, ay, ok := normalizedViewerPoint(mx, my); ok {
					sendAnnot(annotLastX, annotLastY, ax, ay)
					annotLastX, annotLastY = ax, ay
				}
			}
			return 0
		}

		// When panning the viewer, the mouse event belongs to the local viewer.
		// Do not forward it to the remote machine, otherwise the remote cursor
		// can jump while the user is dragging the image.
		viewer.mu.Lock()
		if viewer.dragging {
			if !viewer.fit {
				viewer.panX += float64(mx - viewer.dragX)
				viewer.panY += float64(my - viewer.dragY)
			}
			viewer.dragX, viewer.dragY = mx, my
			viewer.mu.Unlock()
			invalidateRect.Call(hwnd, 0, 0)
			return 0
		}
		viewer.mu.Unlock()

		// Only the viewer image receives remote mouse motion. Letterbox areas
		// remain local and cannot cause a remote cursor jump.
		sendRemoteMouse("move", mx, my, 0, 0)
		return 0
	}
	r, _, _ := defWindowProc.Call(hwnd, uintptr(m), wParam, lParam)
	return r
}

func sendRemoteInput(peer *webrtcpeer.Peer, ev protocol.InputEvent) {
	if peer == nil {
		return
	}
	lastActivityUnix.Store(time.Now().Unix())
	if err := ev.Validate(); err != nil {
		return
	}
	b, err := json.Marshal(ev)
	if err != nil {
		return
	}
	_ = peer.SendControlText("INPUT:" + string(b))
}

func remoteTargetMonitor() (capture.Monitor, bool) {
	activeTargetMonitorMu.RLock()
	mon, ok := activeTargetMonitor, activeTargetMonitorOK
	activeTargetMonitorMu.RUnlock()
	if ok {
		return mon, true
	}
	idx := int(activeMonitor.Load())
	monitors, err := capture.ListMonitors()
	if err == nil && idx >= 0 && idx < len(monitors) {
		return monitors[idx], true
	}
	if len(monitors) > 0 {
		return monitors[0], true
	}
	return capture.Monitor{}, false
}

func normalizedViewerPoint(mx, my int) (float64, float64, bool) {
	viewer.mu.RLock()
	width, height := viewer.width, viewer.height
	fit, zoom, panX, panY := viewer.fit, viewer.zoom, viewer.panX, viewer.panY
	viewer.mu.RUnlock()
	if width <= 0 || height <= 0 {
		return 0, 0, false
	}

	var left, top, drawW, drawH int
	var rc rect
	getClientRect.Call(viewer.hwnd, uintptr(unsafe.Pointer(&rc)))
	dw, dh := int(rc.Right-rc.Left), int(rc.Bottom-rc.Top)
	if fit {
		left, top, drawW, drawH = fitRect(width, height, dw, dh)
	} else {
		drawW = maxInt(1, int(math.Round(float64(width)*zoom)))
		drawH = maxInt(1, int(math.Round(float64(height)*zoom)))
		left, top = int(math.Round(panX)), int(math.Round(panY))
	}
	if drawW <= 0 || drawH <= 0 || mx < left || my < top || mx >= left+drawW || my >= top+drawH {
		return 0, 0, false
	}
	x := float64(mx-left) / float64(drawW)
	y := float64(my-top) / float64(drawH)
	if x < 0 {
		x = 0
	}
	if x > 1 {
		x = 1
	}
	if y < 0 {
		y = 0
	}
	if y > 1 {
		y = 1
	}
	return x, y, true
}

func sendRemoteKey(keyType string, key uint16) {
	state.mu.Lock()
	peer := state.peer
	state.mu.Unlock()
	if peer == nil || key == 0 {
		return
	}
	sendRemoteInput(peer, protocol.InputEvent{T: keyType, K: int(key)})
}

func sendRemoteMouse(moveType string, mx, my int, button int, delta int) {
	state.mu.Lock()
	peer := state.peer
	state.mu.Unlock()
	if peer == nil {
		return
	}
	x, y, ok := normalizedViewerPoint(mx, my)
	if !ok {
		return
	}
	if moveType == "move" {
		viewer.mu.Lock()
		now := time.Now()
		if !viewer.lastMoveAt.IsZero() && now.Sub(viewer.lastMoveAt) < 16*time.Millisecond {
			viewer.mu.Unlock()
			return
		}
		viewer.lastMoveAt = now
		viewer.mu.Unlock()
	}
	sendRemoteInput(peer, protocol.InputEvent{T: moveType, X: x, Y: y, B: button, D: delta})
}

func handleRemoteFile(data []byte) {
	if len(data) < 1 {
		return
	}
	switch data[0] {
	case 0x01:
		var meta struct {
			Name string `json:"name"`
			Size int64  `json:"size"`
		}
		if json.Unmarshal(data[1:], &meta) != nil || meta.Size < 0 || meta.Size > 4*1024*1024*1024 {
			return
		}
		name := filepath.Base(strings.TrimSpace(meta.Name))
		if name == "" || name == "." || name == ".." {
			return
		}
		home, err := os.UserHomeDir()
		if err != nil {
			return
		}
		dir := filepath.Join(home, "Downloads")
		if err := os.MkdirAll(dir, 0755); err != nil {
			return
		}
		final := filepath.Join(dir, name)
		if _, err := os.Stat(final); err == nil {
			ext := filepath.Ext(name)
			stem := strings.TrimSuffix(name, ext)
			for i := 1; ; i++ {
				candidate := filepath.Join(dir, fmt.Sprintf("%s (%d)%s", stem, i, ext))
				if _, e := os.Stat(candidate); os.IsNotExist(e) {
					name, final = filepath.Base(candidate), candidate
					break
				}
			}
		}
		tmp := final + ".part"
		f, err := os.Create(tmp)
		if err != nil {
			return
		}
		fileRx.mu.Lock()
		if fileRx.file != nil {
			_ = fileRx.file.Close()
		}
		fileRx.file, fileRx.name, fileRx.total, fileRx.received, fileRx.tempPath = f, name, meta.Size, 0, tmp
		fileRx.mu.Unlock()
		setStatus(fmt.Sprintf("● Dosya alınıyor: %s  0%%", name))
	case 0x02:
		fileRx.mu.Lock()
		defer fileRx.mu.Unlock()
		if fileRx.file == nil {
			return
		}
		n, err := fileRx.file.Write(data[1:])
		if err != nil {
			_ = fileRx.file.Close()
			fileRx.file = nil
			return
		}
		fileRx.received += int64(n)
		if fileRx.total > 0 {
			setStatus(fmt.Sprintf("● Dosya alınıyor: %s  %d%%", fileRx.name, fileRx.received*100/fileRx.total))
		}
	case 0x03:
		fileRx.mu.Lock()
		defer fileRx.mu.Unlock()
		if fileRx.file == nil {
			return
		}
		_ = fileRx.file.Close()
		final := strings.TrimSuffix(fileRx.tempPath, ".part")
		if err := os.Rename(fileRx.tempPath, final); err != nil {
			setStatus("● Dosya alınamadı: " + err.Error())
		} else {
			setStatus("● Dosya alındı: " + final)
		}
		fileRx.file = nil
		fileRx.tempPath = ""
	case 0x04:
		fileRx.mu.Lock()
		if fileRx.file != nil {
			_ = fileRx.file.Close()
		}
		if fileRx.tempPath != "" {
			_ = os.Remove(fileRx.tempPath)
		}
		fileRx = fileReceiveState{}
		fileRx.mu.Unlock()
		setStatus("● Dosya aktarımı iptal edildi.")
	}
}

func handleRemoteInput(peer *webrtcpeer.Peer, raw string) {
	if strings.HasPrefix(raw, "CHAT:") {
		msg := strings.TrimPrefix(raw, "CHAT:")
		if len(msg) > 2000 {
			msg = msg[:2000]
		}
		addChat(false, msg)
		return
	}
	if raw == "CURTAIN:1" || raw == "CURTAIN:0" {
		if state.hwnd != 0 {
			on := uintptr(0)
			if raw == "CURTAIN:1" {
				on = 1
			}
			postMessage.Call(state.hwnd, WM_APP_CURTAIN, on, 0)
		}
		if raw == "CURTAIN:1" {
			setStatus("● Gizlilik perdesi açıldı.")
		} else {
			setStatus("● Gizlilik perdesi kapatıldı.")
		}
		return
	}
	if raw == "LOCKINPUT:1" {
		blockInput.Call(1)
		setStatus("● Yerel giriş kilitlendi (destek).")
		return
	}
	if raw == "LOCKINPUT:0" {
		blockInput.Call(0)
		setStatus("● Yerel giriş kilidi açıldı.")
		return
	}
	if strings.HasPrefix(raw, "ANNOT:") {
		var a1, b1, c1, d1 float64
		if n, _ := fmt.Sscanf(strings.TrimPrefix(raw, "ANNOT:"), "%f,%f,%f,%f", &a1, &b1, &c1, &d1); n == 4 {
			annotMu.Lock()
			annotPending = append(annotPending, annotSegN{a1, b1, c1, d1})
			annotMu.Unlock()
			if state.hwnd != 0 {
				postMessage.Call(state.hwnd, WM_APP_ANNOT, 0, 0)
			}
		}
		return
	}
	if raw == "ANNOT_CLEAR" {
		if state.hwnd != 0 {
			postMessage.Call(state.hwnd, WM_APP_ANNOT, 1, 0)
		}
		return
	}
	if raw == "SYSINFO_REQ" {
		if peer != nil {
			_ = peer.SendControlText("SYSINFO:" + gatherSysInfo())
		}
		return
	}
	if strings.HasPrefix(raw, "SYSINFO:") {
		info := strings.TrimPrefix(raw, "SYSINFO:")
		go messageBox.Call(0, uintptr(unsafe.Pointer(utf16ptr(info))), uintptr(unsafe.Pointer(utf16ptr("Uzak Sistem Bilgisi"))), 0x00000040)
		return
	}
	if raw == "CLIP_REQ" {
		if sendClipboardToPeer(peer) {
			setStatus("● Pano karşı bilgisayara gönderildi.")
		}
		return
	}
	if strings.HasPrefix(raw, "CLIP:") {
		payload := strings.TrimPrefix(raw, "CLIP:")
		data, err := base64.StdEncoding.DecodeString(payload)
		if err != nil || len(data) > 48*1024 {
			return
		}
		if copyToClipboard(string(data)) {
			setStatus("● Uzak pano yerel panoya aktarıldı.")
		}
		return
	}
	if strings.HasPrefix(raw, "FILE_BEGIN:") || strings.HasPrefix(raw, "FILE_CHUNK:") || raw == "FILE_ABORT" || raw == "FILE_END" {
		return
	}
	if strings.HasPrefix(raw, "MONITORS:") {
		var monitors []capture.Monitor
		if err := json.Unmarshal([]byte(strings.TrimPrefix(raw, "MONITORS:")), &monitors); err == nil && len(monitors) > 0 {
			remoteMonitorsMu.Lock()
			remoteMonitors = append([]capture.Monitor(nil), monitors...)
			remoteMonitorsMu.Unlock()
			if int(activeMonitor.Load()) >= len(monitors) {
				activeMonitor.Store(0)
			}
			// Win32 child-window operations must run on the GUI thread.
			// WebRTC callbacks run on worker goroutines, so marshal the UI
			// update through PostMessage instead of creating/destroying
			// buttons directly from the callback goroutine.
			state.mu.Lock()
			hwnd := state.hwnd
			state.mu.Unlock()
			if hwnd != 0 {
				postMessage.Call(hwnd, WM_APP_MONITORS, uintptr(len(monitors)), 0)
			}
		}
		return
	}
	if strings.HasPrefix(raw, "RESOLUTION:") {
		if state.mode != 1 {
			return
		}
		var h int
		if _, err := fmt.Sscanf(strings.TrimPrefix(raw, "RESOLUTION:"), "%d", &h); err == nil {
			if h == 0 || h == 480 || h == 720 || h == 1080 {
				captureMaxHeight.Store(int32(h))
				setStatus(fmt.Sprintf("● Ekran aktarım çözünürlüğü: %s", map[int]string{0: "Otomatik", 480: "480p", 720: "720p", 1080: "1080p"}[h]))
			}
		}
		return
	}
	if strings.HasPrefix(raw, "MONITOR:") {
		if state.mode != 1 {
			return
		}
		var idx int
		if _, err := fmt.Sscanf(strings.TrimPrefix(raw, "MONITOR:"), "%d", &idx); err == nil && idx >= 0 {
			if monitors, err := capture.ListMonitors(); err == nil && idx < len(monitors) {
				mon := monitors[idx]
				activeMonitor.Store(int32(idx))
				activeTargetMonitorMu.Lock()
				activeTargetMonitor = mon
				activeTargetMonitorOK = true
				activeTargetMonitorMu.Unlock()
				setStatus(fmt.Sprintf("● Monitör %d/%d aktarılıyor", idx+1, len(monitors)))
			}
		}
		return
	}
	if strings.HasPrefix(raw, "HELLO:") {
		remoteHost := strings.TrimSpace(strings.TrimPrefix(raw, "HELLO:"))
		setRemoteHost(remoteHost)
		if state.hwnd != 0 {
			invalidateRect.Call(state.hwnd, 0, 0)
		}
		localHost, _ := os.Hostname()
		if remoteHost != "" && localHost != "" && strings.EqualFold(remoteHost, localHost) {
			sameHostPeer.Store(true)
			setStatus("● Loopback test modu: remote mouse/klavye etkin")
		}
		return
	}
	if !strings.HasPrefix(raw, "INPUT:") {
		return
	}
	var ev protocol.InputEvent
	if err := json.Unmarshal([]byte(strings.TrimPrefix(raw, "INPUT:")), &ev); err != nil {
		return
	}
	if err := ev.Validate(); err != nil {
		return
	}
	if ev.T == "move" || ev.T == "down" || ev.T == "up" || ev.T == "wheel" {
		injectRemoteMouse(ev)
		return
	}
	if ev.T == "keydown" || ev.T == "keyup" {
		injectRemoteKey(ev)
	}
}

func systemMetric(index int) int32 {
	r1, _, _ := getSystemMetrics.Call(uintptr(index))
	return int32(r1)
}

func normalizedToVirtualScreen(x, y float64) (int32, int32, bool) {
	mon, ok := remoteTargetMonitor()
	if !ok || mon.Width <= 0 || mon.Height <= 0 {
		return 0, 0, false
	}
	// The streamed image is monitor 0. Map normalized viewer coordinates to
	// that monitor's virtual-desktop rectangle, then to SendInput's 0..65535
	// virtual-screen coordinate space.
	px := float64(mon.X) + x*float64(maxInt(1, mon.Width-1))
	py := float64(mon.Y) + y*float64(maxInt(1, mon.Height-1))
	left := systemMetric(76)
	top := systemMetric(77)
	width := systemMetric(78)
	height := systemMetric(79)
	if width <= 1 || height <= 1 {
		return 0, 0, false
	}
	vx := int32(math.Round((px - float64(left)) * 65535 / float64(width-1)))
	vy := int32(math.Round((py - float64(top)) * 65535 / float64(height-1)))
	return vx, vy, true
}

func absoluteMouseInput(ev protocol.InputEvent, extraFlags uint32, mouseData uint32) (winInput, bool) {
	dx, dy, ok := normalizedToVirtualScreen(ev.X, ev.Y)
	if !ok {
		return winInput{}, false
	}
	return winInput{Type: inputMouse, Mi: winMouseInput{
		Dx: dx, Dy: dy, MouseData: mouseData,
		DwFlags: mouseAbsolute | mouseVirtual | extraFlags,
	}}, true
}

func injectRemoteMouse(ev protocol.InputEvent) {
	lastActivityUnix.Store(time.Now().Unix())
	flags := uint32(mouseMove)
	data := uint32(0)
	switch ev.T {
	case "move":
		flags = mouseMove
	case "down":
		switch ev.B {
		case 0:
			flags = mouseLeftDown
		case 1:
			flags = mouseMiddleDown
		case 2:
			flags = mouseRightDown
		}
	case "up":
		switch ev.B {
		case 0:
			flags = mouseLeftUp
		case 1:
			flags = mouseMiddleUp
		case 2:
			flags = mouseRightUp
		}
	case "wheel":
		flags = mouseWheel
		data = uint32(int32(ev.D))
	}
	in, ok := absoluteMouseInput(ev, flags, data)
	if !ok {
		return
	}
	// Do not immediately restore the physical cursor. SendInput is queued,
	// and SetCursorPos here can race the injected event on monitor 2/3.
	_, _, _ = sendInput.Call(1, uintptr(unsafe.Pointer(&in)), uintptr(unsafe.Sizeof(in)))
}

func injectRemoteKey(ev protocol.InputEvent) {
	lastActivityUnix.Store(time.Now().Unix())
	vk := uint16(ev.K)
	if vk == 0 {
		return
	}
	// Use physical scan codes for navigation/modifier keys. This is important
	// for combinations such as Ctrl+Left/Ctrl+Right, where Windows text
	// controls rely on the extended-key semantics of the arrow keys.
	scanResult, _, _ := mapVirtualKey.Call(uintptr(vk), 0)
	scan := uint16(scanResult)
	flags := uint32(keyScancode)
	if ev.T == "keyup" {
		flags |= keyUp
	}
	if isExtendedVirtualKey(vk) {
		flags |= keyExtended
	}
	in := winKeyInput{Type: inputKeyboard, Ki: winKeyboardInput{
		Vk: vk, Scan: scan, Flags: flags,
	}}
	_, _, _ = sendInput.Call(1, uintptr(unsafe.Pointer(&in)), uintptr(unsafe.Sizeof(in)))
}

func isExtendedVirtualKey(vk uint16) bool {
	switch vk {
	case 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x6F:
		return true
	}
	return false
}

func chooseFile() (string, bool) {
	buf := make([]uint16, 32768)
	// Build a valid double-NUL-terminated filter (utf16ptr stops at the first NUL).
	fa, _ := syscall.UTF16FromString("Tüm Dosyalar (*.*)")
	fb, _ := syscall.UTF16FromString("*.*")
	filterBuf := append(append(fa, fb...), 0)
	ofn := openFileName{
		StructSize: uint32(unsafe.Sizeof(openFileName{})),
		Owner:      state.hwnd,
		Filter:     &filterBuf[0],
		File:       &buf[0],
		MaxFile:    uint32(len(buf)),
		Flags:      0x00080000 | 0x00001000 | 0x00000800, // OFN_EXPLORER | FILEMUSTEXIST | PATHMUSTEXIST
	}
	r, _, _ := getOpenFileName.Call(uintptr(unsafe.Pointer(&ofn)))
	runtime.KeepAlive(filterBuf)
	runtime.KeepAlive(buf)
	if r == 0 {
		code, _, _ := commDlgError.Call()
		if code != 0 {
			msg := utf16ptr(fmt.Sprintf("Dosya seçici açılamadı (hata kodu %d).", code))
			title := utf16ptr(brandName())
			messageBox.Call(state.hwnd, uintptr(unsafe.Pointer(msg)), uintptr(unsafe.Pointer(title)), 0x00000010)
		}
		return "", false
	}
	return syscall.UTF16ToString(buf), true
}

func fileNotify(msg string) {
	setStatus("● " + msg)
}

func sendFileToPeer(path string) {
	fileSendMu.Lock()
	defer fileSendMu.Unlock()

	state.mu.Lock()
	peer := state.peer
	state.mu.Unlock()
	if peer == nil || peer.ConnectionState() != webrtc.PeerConnectionStateConnected {
		fileNotify("Dosya gönderilemiyor: bağlantı hazır değil.")
		return
	}
	f, err := os.Open(path)
	if err != nil {
		setStatus("● Dosya açılamadı: " + err.Error())
		return
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil {
		setStatus("● Dosya bilgisi okunamadı: " + err.Error())
		return
	}
	if info.Size() > 4*1024*1024*1024 {
		setStatus("● Dosya 4 GB sınırını aşıyor.")
		return
	}
	setStatus("● Dosya kanalı hazırlanıyor...")
	deadline := time.Now().Add(10 * time.Second)
	for !peer.FileReady() {
		if time.Now().After(deadline) {
			fileNotify("Dosya kanalı hazır değil (10 sn içinde açılmadı).")
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
	meta, _ := json.Marshal(struct {
		Name string `json:"name"`
		Size int64  `json:"size"`
	}{filepath.Base(path), info.Size()})
	if err := peer.SendFileData(append([]byte{0x01}, meta...)); err != nil {
		fileNotify("Dosya başlatılamadı: " + err.Error())
		return
	}
	buf := make([]byte, 48*1024)
	var sent int64
	for {
		n, readErr := f.Read(buf)
		if n > 0 {
			packet := make([]byte, n+1)
			packet[0] = 0x02
			copy(packet[1:], buf[:n])
			for peer.FileBufferedAmount() > 8*1024*1024 {
				time.Sleep(5 * time.Millisecond)
			}
			if err := peer.SendFileData(packet); err != nil {
				_ = peer.SendFileData([]byte{0x04})
				fileNotify("Dosya gönderimi kesildi: " + err.Error())
				return
			}
			sent += int64(n)
			pct := int64(100)
			if info.Size() > 0 {
				pct = sent * 100 / info.Size()
			}
			setStatus(fmt.Sprintf("● Gönderiliyor: %s  %d%%", filepath.Base(path), pct))
		}
		if readErr == io.EOF {
			break
		}
		if readErr != nil {
			_ = peer.SendFileData([]byte{0x04})
			setStatus("● Dosya okuma hatası: " + readErr.Error())
			return
		}
	}
	if err := peer.SendFileData([]byte{0x03}); err != nil {
		setStatus("● Dosya tamamlanamadı: " + err.Error())
		return
	}
	fileNotify("Dosya gönderildi: " + filepath.Base(path))
}

func sendRemoteMonitorList(peer *webrtcpeer.Peer) {
	monitors, err := capture.ListMonitors()
	if err != nil || len(monitors) == 0 {
		return
	}
	b, err := json.Marshal(monitors)
	if err != nil {
		return
	}
	_ = peer.SendControlText("MONITORS:" + string(b))
}

func startCapture(peer *webrtcpeer.Peer, ctx context.Context) {
	go func() {
		defer logCrash("capture")
		defer clearPrivacy()
		if err := peer.WaitScreen(ctx); err != nil {
			if ctx.Err() == nil {
				setStatus("● Ekran kanalı bekleniyor: " + err.Error())
			}
			return
		}
		setStatus("● Ekran kanalı hazır. Ekran aktarılıyor...")
		ticker := time.NewTicker(100 * time.Millisecond)
		defer ticker.Stop()
		var seq uint64
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				monitor := int(activeMonitor.Load())
				maxHeight := int(captureMaxHeight.Load())
				cfg := currentSettings()
				quality := cfg.Quality
				if quality == 0 {
					quality = 88
				}
				frame, err := capture.CaptureMonitorScaled(monitor, quality, maxHeight)
				if err != nil {
					setStatus("● Ekran yakalanamadı: " + err.Error())
					return
				}
				if len(frame.JPEG) > screen.MaxPayloadSize {
					fallbackQuality := 76
					if quality < 80 {
						fallbackQuality = quality
					}
					frame, err = capture.CaptureMonitorScaled(monitor, fallbackQuality, maxHeight)
					if err != nil {
						setStatus("● Ekran sıkıştırılamadı: " + err.Error())
						return
					}
				}
				seq++
				err = peer.SendScreenFrame(screen.Frame{
					Monitor: uint16(monitor),
					Seq:     seq,
					Width:   uint32(frame.Width),
					Height:  uint32(frame.Height),
					JPEG:    frame.JPEG,
				})
				if err != nil {
					setStatus("● Ekran DataChannel gönderim hatası: " + err.Error())
					capturing.Store(false)
					return
				}
				// Bir kare fiilen bu makineden çıktı: agent artık görülüyor.
				if capturing.CompareAndSwap(false, true) && state.hwnd != 0 {
					invalidateRect.Call(state.hwnd, 0, 0)
				}
			}
		}
	}()
}

func startEmbeddedSignaling() {
	// Bind the port ourselves so we KNOW we own it. The old probe only checked
	// whether *something* answered on :8091, so a leftover/old RemoteSupport
	// instance holding the port made us use ITS (6-digit) signaling. Now we use
	// our own 10-digit server when we can bind, and warn clearly when we cannot.
	ln, err := net.Listen("tcp", "0.0.0.0:8091")
	if err != nil {
		log.Printf("Embedded signaling could not bind :8091: %v", err)
		setStatus("● 8091 portu meşgul: açık/eski bir NexDesk örneği olabilir. Onu kapatıp yeniden başlatın.")
		return
	}
	s := server.NewServer()
	embeddedSignalingReady.Store(true)
	go func() {
		if e := http.Serve(ln, s.Handler()); e != nil {
			log.Printf("Embedded signaling stopped: %v", e)
			embeddedSignalingReady.Store(false)
		}
	}()
	go serveEmbeddedDiscovery()
}

func serveEmbeddedDiscovery() {
	pc, err := net.ListenPacket("udp4", ":8090")
	if err != nil {
		log.Printf("Embedded LAN discovery unavailable: %v", err)
		return
	}
	defer pc.Close()
	buf := make([]byte, 256)
	for {
		_ = pc.SetReadDeadline(time.Now().Add(2 * time.Second))
		n, peer, err := pc.ReadFrom(buf)
		if err != nil {
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				continue
			}
			continue
		}
		if strings.TrimSpace(string(buf[:n])) != "REMOTESUPPORT_DISCOVER_V1" {
			continue
		}
		ip := localIPv4ForPeer(peer)
		if ip == "" {
			continue
		}
		_, _ = pc.WriteTo([]byte("REMOTESUPPORT_SIGNALING_V1 ws://"+ip+":8091/v1/ws"), peer)
	}
}

func localIPv4ForPeer(peer net.Addr) string {
	udpPeer, ok := peer.(*net.UDPAddr)
	if !ok {
		return ""
	}
	interfaces, err := net.Interfaces()
	if err != nil {
		return ""
	}
	for _, iface := range interfaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, a := range addrs {
			ipnet, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			ip := ipnet.IP.To4()
			if ip == nil {
				continue
			}
			if ip.Equal(udpPeer.IP) || ipnet.Contains(udpPeer.IP) {
				return ip.String()
			}
		}
	}
	return ""
}

func signalingEndpoint() string {
	if v := strings.TrimSpace(os.Getenv("REMOTESUPPORT_SIGNALING_URL")); v != "" {
		return v
	}
	cfg := currentSettings()
	if v := strings.TrimSpace(cfg.SignalingURL); v != "" {
		return v
	}
	if embeddedSignalingReady.Load() {
		return "ws://127.0.0.1:8091/v1/ws"
	}
	if v := discoverSignalingEndpoint(1200 * time.Millisecond); v != "" {
		return v
	}
	return defaultSignalingURL
}

func discoverSignalingEndpoint(timeout time.Duration) string {
	conn, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4zero, Port: 0})
	if err != nil {
		return ""
	}
	defer conn.Close()
	if raw, err := conn.SyscallConn(); err == nil {
		_ = raw.Control(func(fd uintptr) {
			_ = windows.SetsockoptInt(windows.Handle(fd), windows.SOL_SOCKET, windows.SO_BROADCAST, 1)
		})
	}
	deadline := time.Now().Add(timeout)
	_ = conn.SetReadDeadline(deadline)
	msg := []byte("REMOTESUPPORT_DISCOVER_V1")
	for _, bcast := range discoveryBroadcasts() {
		_, _ = conn.WriteToUDP(msg, &net.UDPAddr{IP: bcast, Port: 8090})
	}
	buf := make([]byte, 256)
	for time.Now().Before(deadline) {
		n, _, err := conn.ReadFromUDP(buf)
		if err != nil {
			return ""
		}
		line := strings.TrimSpace(string(buf[:n]))
		if strings.HasPrefix(line, "REMOTESUPPORT_SIGNALING_V1 ") {
			u := strings.TrimSpace(strings.TrimPrefix(line, "REMOTESUPPORT_SIGNALING_V1 "))
			if parsed, err := url.Parse(u); err == nil && parsed.Scheme == "ws" && parsed.Host != "" {
				return u
			}
		}
	}
	return ""
}

func discoveryBroadcasts() []net.IP {
	result := []net.IP{net.IPv4bcast}
	ifaces, err := net.Interfaces()
	if err != nil {
		return result
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, a := range addrs {
			ipnet, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			ip := ipnet.IP.To4()
			mask := ipnet.Mask
			if ip == nil || len(mask) != 4 {
				continue
			}
			b := make(net.IP, 4)
			for i := 0; i < 4; i++ {
				b[i] = ip[i] | ^mask[i]
			}
			result = append(result, b)
		}
	}
	return result
}

func newCode() string {
	// The server is authoritative for the actual connection code.
	// This value is only used before Create() returns.
	return "------"
}

func setText(hwnd uintptr, text string) {
	if hwnd != 0 {
		sendMessage.Call(hwnd, 0x000C, 0, uintptr(unsafe.Pointer(utf16ptr(text))))
	}
}

func getText(hwnd uintptr) string {
	if hwnd == 0 {
		return ""
	}
	buf := make([]uint16, 128)
	getWindowText.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf)
}

func setStatus(text string) {
	state.mu.Lock()
	state.statusText = text
	h := state.status
	state.mu.Unlock()
	if h != 0 {
		setText(h, text)
	}
	if state.hwnd != 0 {
		invalidateRect.Call(state.hwnd, 0, 0)
	}
}

func setCode(text string) {
	state.mu.Lock()
	h := state.codeLabel
	state.mu.Unlock()
	if h != 0 {
		setText(h, text)
	}
}

func setModeVisible(mode int) {
	state.mu.Lock()
	state.mode = mode
	homeA, homeB := state.action, state.copy
	state.mu.Unlock()
	_ = homeA
	_ = homeB
}

func moveControl(hwnd uintptr, x, y, w, h int, visible bool) {
	if hwnd == 0 {
		return
	}
	setWindowPos.Call(hwnd, 0, uintptr(x), uintptr(y), uintptr(maxInt(1, w)), uintptr(maxInt(1, h)), 0x0004|0x0010)
	if visible {
		show(hwnd)
	} else {
		hide(hwnd)
	}
}

func layoutUI() {
	if state.hwnd == 0 {
		return
	}
	var rc rect
	getClientRect.Call(state.hwnd, uintptr(unsafe.Pointer(&rc)))
	w := int(rc.Right - rc.Left)
	h := int(rc.Bottom - rc.Top)
	if w < 700 || h < 500 {
		return
	}

	state.mu.Lock()
	mode := state.mode
	state.mu.Unlock()
	viewer.mu.RLock()
	connected := viewer.active
	viewer.mu.RUnlock()

	// Header and footer are painted by the main window. Keep legacy text controls hidden.
	hide(state.header)
	hide(state.subtitle)
	hide(state.status)
	hide(state.elevate)
	hide(state.clipSend)
	hide(state.clipGet)
	hide(state.chatInput)
	hide(state.chatSend)
	hide(state.stayOpen)
	hide(state.actionsBtn)
	hide(state.shareLink)

	if connected && !fullscreen.Load() {
		// Toolbar action buttons sit on the painted toolbar surface (y≈104).
		moveControl(state.fullscreenButton, w-158, 104, 134, 40, true)
		moveControl(state.actionsBtn, w-306, 104, 140, 40, true)
		hide(state.fileSend)
		hide(state.clipGet)
		hide(state.clipSend)
		cg := computeChatGeom(w, h)
		if cg.visible {
			moveControl(state.chatInput, cg.inputX, cg.inputY, cg.inputW, cg.inputH, true)
			moveControl(state.chatSend, cg.sendX, cg.inputY, cg.sendW, cg.inputH, true)
		}
		// Prominent red disconnect in the header (ID_BACK stops the session).
		setText(state.back, "Bağlantıyı Kes")
		moveControl(state.back, w-190, 22, 166, 42, true)
		moveControl(state.stayOpen, w-370, 22, 150, 42, idleWarn.Load())
		moveControl(state.action, 0, 0, 1, 1, false)
		moveControl(state.copy, 0, 0, 1, 1, false)
		moveControl(state.codeLabel, 0, 0, 1, 1, false)
		moveControl(state.remoteEdit, 0, 0, 1, 1, false)
		return
	}
	if connected && fullscreen.Load() {
		hide(state.fileSend)
		hide(state.fullscreenButton)
		return
	}

	if mode == 10 {
		moveControl(state.settingsEndpoint, 520, 200, 560, 40, true)
		moveControl(state.settingsTurnURL, 284, 320, 664, 30, true)
		moveControl(state.settingsTurnUser, 284, 358, 250, 30, true)
		moveControl(state.settingsTurnPass, 622, 358, 326, 30, true)
		moveControl(state.settingsQuality, 520, 434, 180, 240, true)
		moveControl(state.settingsResolution, 760, 434, 180, 240, true)
		moveControl(state.settingsIdle, 520, 522, 180, 240, true)
		moveControl(state.settingsIdleAction, 760, 522, 260, 240, true)
		moveControl(state.settingsSave, 520, 610, 180, 44, true)
		moveControl(state.settingsReset, 720, 610, 220, 44, true)
		return
	}
	if mode == 11 {
		return
	}

	if mode == 0 {
		// Two primary action cards, side by side, tracking the window width.
		contentW := w - contentX - gutter
		cardGap := 24
		cardW := (contentW - cardGap) / 2
		cardY := 176
		cardH := 200
		moveControl(state.homeGet, contentX, cardY, cardW, cardH, true)
		moveControl(state.homeGive, contentX+cardW+cardGap, cardY, cardW, cardH, true)
		moveControl(state.elevate, w-gutter-260, 110, 260, 40, !isElevated())
		moveControl(state.back, 184, 500, 150, 48, false)
		moveControl(state.action, 350, 500, 250, 48, false)
		moveControl(state.copy, 620, 500, 170, 48, false)
		moveControl(state.codeLabel, 184, 350, 816, 110, false)
		moveControl(state.remoteEdit, 184, 350, 816, 58, false)
		return
	}

	if mode == 1 {
		if capturing.Load() {
			setText(state.back, "Bağlantıyı Kes")
			hide(state.codeLabel)
			hide(state.copy)
			hide(state.remoteEdit)
			hide(state.action)
			cg := computeChatGeom(w, h)
			if cg.visible {
				moveControl(state.chatInput, cg.inputX, cg.inputY, cg.inputW, cg.inputH, true)
				moveControl(state.chatSend, cg.sendX, cg.inputY, cg.sendW, cg.inputH, true)
			}
			moveControl(state.back, w-gutter-180, 118, 168, 40, true)
			moveControl(state.stayOpen, contentX, 214, 150, 40, idleWarn.Load())
			return
		}
		setText(state.back, "‹ Geri")
		hide(state.chatInput)
		hide(state.chatSend)
		moveControl(state.codeLabel, 214, 344, 560, 86, true)
		moveControl(state.copy, 784, 356, 158, 62, true)
		moveControl(state.shareLink, 784, 426, 158, 40, true)
		moveControl(state.remoteEdit, 178, 335, 782, 58, false)
		moveControl(state.back, contentX, 566, 140, 46, true)
		moveControl(state.action, contentX+156, 566, 260, 46, true)
		return
	}

	if mode == 2 {
		setText(state.back, "‹ Geri")
		moveControl(state.remoteEdit, contentX, 356, 620, 62, true)
		moveControl(state.action, contentX+636, 356, 146, 62, true) // Bağlan next to input
		moveControl(state.copy, 0, 0, 1, 1, false)
		moveControl(state.codeLabel, 0, 0, 1, 1, false)
		moveControl(state.back, contentX, 470, 140, 46, true)
	}
}

// Text alignment flags for paintText (DrawTextW).
const (
	dtCenter     = 0x00000001
	dtRight      = 0x00000002
	dtVCenter    = 0x00000004
	dtSingleLine = 0x00000020
	dtWordBreak  = 0x00000010
	dtEndEllip   = 0x00008000

	txLeft   = 0x00000000
	txMid    = dtCenter | dtVCenter | dtSingleLine // centered both axes (icons, pills)
	txVLeft  = dtVCenter | dtSingleLine            // left, vertically centered
	txVRight = dtRight | dtVCenter | dtSingleLine  // right, vertically centered
	txEnd    = dtVCenter | dtSingleLine | dtEndEllip
	txWrap   = dtWordBreak
)

func paintText(hdc uintptr, text string, x, y, w, h int, font uintptr, color uint32, flags uint32) {
	if hdc == 0 || text == "" {
		return
	}
	setBkMode.Call(hdc, 1)
	setTextColor.Call(hdc, rgb(color))
	old, _, _ := selectObject.Call(hdc, font)
	r := rect{Left: int32(x), Top: int32(y), Right: int32(x + w), Bottom: int32(y + h)}
	drawText.Call(hdc, uintptr(unsafe.Pointer(utf16ptr(text))), ^uintptr(0), uintptr(unsafe.Pointer(&r)), uintptr(flags))
	selectObject.Call(hdc, old)
}

func paintRoundPanel(hdc uintptr, x, y, w, h int, color uint32, radius int) {
	brush, _, _ := createSolidBrush.Call(rgb(color))
	if brush == 0 {
		return
	}
	// Match pen to the fill so RoundRect's 1px outline doesn't leave a stray edge.
	pen, _, _ := createPen.Call(0, 1, rgb(color))
	oldBrush, _, _ := selectObject.Call(hdc, brush)
	oldPen, _, _ := selectObject.Call(hdc, pen)
	roundRect.Call(hdc, uintptr(x), uintptr(y), uintptr(x+w), uintptr(y+h), uintptr(radius), uintptr(radius))
	selectObject.Call(hdc, oldBrush)
	selectObject.Call(hdc, oldPen)
	deleteObject.Call(brush)
	if pen != 0 {
		deleteObject.Call(pen)
	}
}

// paintCard draws a filled rounded panel with a 1px border, the standard card
// look used throughout the concept (soft surface + hairline edge).
func paintCard(hdc uintptr, x, y, w, h int, fill, border uint32, radius int) {
	brush, _, _ := createSolidBrush.Call(rgb(fill))
	pen, _, _ := createPen.Call(0, 1, rgb(border))
	oldBrush, _, _ := selectObject.Call(hdc, brush)
	oldPen, _, _ := selectObject.Call(hdc, pen)
	roundRect.Call(hdc, uintptr(x), uintptr(y), uintptr(x+w), uintptr(y+h), uintptr(radius), uintptr(radius))
	selectObject.Call(hdc, oldBrush)
	selectObject.Call(hdc, oldPen)
	if brush != 0 {
		deleteObject.Call(brush)
	}
	if pen != 0 {
		deleteObject.Call(pen)
	}
}

// paintDot draws a small filled circle (status indicators, timeline bullets).
func paintDot(hdc uintptr, cx, cy, r int, color uint32) {
	brush, _, _ := createSolidBrush.Call(rgb(color))
	pen, _, _ := createPen.Call(0, 1, rgb(color))
	ob, _, _ := selectObject.Call(hdc, brush)
	op, _, _ := selectObject.Call(hdc, pen)
	ellipse.Call(hdc, uintptr(cx-r), uintptr(cy-r), uintptr(cx+r), uintptr(cy+r))
	selectObject.Call(hdc, ob)
	selectObject.Call(hdc, op)
	if brush != 0 {
		deleteObject.Call(brush)
	}
	if pen != 0 {
		deleteObject.Call(pen)
	}
}

// paintGlow fakes a soft glow behind an accent tile by stacking a few
// progressively larger, darker rounded rectangles (no alpha channel in GDI).
func paintGlow(hdc uintptr, x, y, w, h int, color uint32, radius int) {
	for i := 3; i >= 1; i-- {
		g := i * 3
		paintRoundPanel(hdc, x-g, y-g, w+2*g, h+2*g, uint32(mixHex(uiBgColor, color, 0.10*float64(4-i))), radius+g)
	}
}

// mixHex is mix() but returns a 0xRRGGBB value (for callers that need a literal).
func mixHex(a, b uint32, t float64) uint32 {
	if t < 0 {
		t = 0
	}
	if t > 1 {
		t = 1
	}
	ar, ag, ab := (a>>16)&0xFF, (a>>8)&0xFF, a&0xFF
	br, bg, bb := (b>>16)&0xFF, (b>>8)&0xFF, b&0xFF
	r := uint32(float64(ar) + (float64(br)-float64(ar))*t)
	g := uint32(float64(ag) + (float64(bg)-float64(ag))*t)
	bl := uint32(float64(ab) + (float64(bb)-float64(ab))*t)
	return r<<16 | g<<8 | bl
}

// Shared shell geometry. Child-control layout in layoutUI() and the viewer in
// resizeViewer() are anchored to these same numbers, so keep them in sync.
const (
	navW     = 164
	headerH  = 86
	footerH  = 52
	contentX = 184
	gutter   = 24
)

// ---- In-session text chat (over the control data channel) ----

type chatMsg struct {
	mine bool
	text string
}

var chatMu sync.Mutex
var chatLog []chatMsg

func addChat(mine bool, text string) {
	text = strings.TrimSpace(text)
	if text == "" {
		return
	}
	chatMu.Lock()
	chatLog = append(chatLog, chatMsg{mine: mine, text: text})
	if len(chatLog) > 200 {
		chatLog = chatLog[len(chatLog)-200:]
	}
	chatMu.Unlock()
	if state.hwnd != 0 {
		invalidateRect.Call(state.hwnd, 0, 0)
	}
}

func chatSnapshot() []chatMsg {
	chatMu.Lock()
	defer chatMu.Unlock()
	return append([]chatMsg(nil), chatLog...)
}

func resetChat() {
	chatMu.Lock()
	chatLog = nil
	chatMu.Unlock()
}

func sendChat() {
	txt := strings.TrimSpace(getText(state.chatInput))
	if txt == "" {
		return
	}
	if len(txt) > 2000 {
		txt = txt[:2000]
	}
	state.mu.Lock()
	pr := state.peer
	state.mu.Unlock()
	if pr == nil {
		return
	}
	if err := pr.SendControlText("CHAT:" + txt); err != nil {
		setStatus("● Mesaj gönderilemedi.")
		return
	}
	addChat(true, txt)
	setText(state.chatInput, "")
}

type chatGeom struct {
	x, y, w, h                     int
	inputX, inputY, inputW, inputH int
	sendX, sendW                   int
	visible                        bool
}

// computeChatGeom returns the chat panel + input geometry for the active view:
// a right-hand column for the operator, a wide area below the banner for the
// agent, or invisible when no session is on screen.
func computeChatGeom(w, h int) chatGeom {
	viewer.mu.RLock()
	active := viewer.active
	viewer.mu.RUnlock()
	inputH := 40
	if active && !fullscreen.Load() {
		cw := 300
		cx := w - gutter - cw
		cy := 160 // below the toolbar strip (was 106, overlapped the buttons)
		ch := h - footerH - 16 - cy - (inputH + 10)
		if ch < 60 {
			ch = 60
		}
		g := chatGeom{x: cx, y: cy, w: cw, h: ch, visible: true, inputY: cy + ch + 8, inputH: inputH}
		g.sendW = 84
		g.inputX = cx
		g.inputW = cw - g.sendW - 8
		g.sendX = cx + g.inputW + 8
		return g
	}
	state.mu.Lock()
	mode := state.mode
	state.mu.Unlock()
	if mode == 1 && capturing.Load() {
		cx := contentX
		cw := w - contentX - gutter
		cy := 250
		ch := h - footerH - 16 - cy - (inputH + 10)
		if ch < 60 {
			ch = 60
		}
		g := chatGeom{x: cx, y: cy, w: cw, h: ch, visible: true, inputY: cy + ch + 8, inputH: inputH}
		g.sendW = 110
		g.inputX = cx
		g.inputW = cw - g.sendW - 8
		g.sendX = cx + g.inputW + 8
		return g
	}
	return chatGeom{visible: false}
}

func paintChatPanel(hdc uintptr, g chatGeom) {
	if !g.visible {
		return
	}
	paintCard(hdc, g.x, g.y, g.w, g.h, uiPanelColor, uiBorderColor, 12)
	paintText(hdc, "SOHBET", g.x+16, g.y+12, g.w-32, 16, uiLabelFont, uiMutedColor, txVLeft)
	fillBand(hdc, g.x+16, g.y+36, g.w-32, 1, rgb(uiBorderColor))
	msgs := chatSnapshot()
	lineH := 38
	top := g.y + 46
	avail := (g.y + g.h - 10 - top) / lineH
	if avail < 1 {
		avail = 1
	}
	if len(msgs) > avail {
		msgs = msgs[len(msgs)-avail:]
	}
	if len(msgs) == 0 {
		paintText(hdc, "Henüz mesaj yok. Karşı tarafla yazışabilirsiniz.", g.x+16, top, g.w-32, 20, uiBodyFont, uiFaintColor, txVLeft)
		return
	}
	y := top
	for _, m := range msgs {
		who := "Karşı taraf"
		var col uint32 = uiMutedColor
		if m.mine {
			who = "Siz"
			col = uiAccentHi
		}
		paintText(hdc, who, g.x+16, y, g.w-32, 14, uiSmallFont, col, txVLeft)
		paintText(hdc, m.text, g.x+16, y+15, g.w-32, 20, uiBodyFont, uiTextColor, txEnd)
		y += lineH
	}
}

// ---- Recent connections (persisted to the config dir) ----
type recentConn struct {
	Role string `json:"role"`
	Code string `json:"code"`
	At   int64  `json:"at"`
}

var recentMu sync.Mutex
var recentList []recentConn

func recentPath() string {
	base, err := os.UserConfigDir()
	if err != nil || base == "" {
		return ""
	}
	dir := filepath.Join(base, "RemoteSupport")
	_ = os.MkdirAll(dir, 0700)
	return filepath.Join(dir, "recent.json")
}

func loadRecent() {
	path := recentPath()
	if path == "" {
		return
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return
	}
	var list []recentConn
	if json.Unmarshal(b, &list) != nil {
		return
	}
	if len(list) > 8 {
		list = list[:8]
	}
	recentMu.Lock()
	recentList = list
	recentMu.Unlock()
}

func addRecent(role, code string) {
	code = strings.ReplaceAll(strings.TrimSpace(code), " ", "")
	if code == "" {
		return
	}
	rc := recentConn{Role: role, Code: code, At: time.Now().Unix()}
	recentMu.Lock()
	recentList = append([]recentConn{rc}, recentList...)
	if len(recentList) > 8 {
		recentList = recentList[:8]
	}
	snap := append([]recentConn(nil), recentList...)
	recentMu.Unlock()
	if path := recentPath(); path != "" {
		if b, err := json.MarshalIndent(snap, "", "  "); err == nil {
			_ = os.WriteFile(path, b, 0600)
		}
	}
	if state.hwnd != 0 {
		invalidateRect.Call(state.hwnd, 0, 0)
	}
}

func recentSnapshot() []recentConn {
	recentMu.Lock()
	defer recentMu.Unlock()
	return append([]recentConn(nil), recentList...)
}

func relativeTime(unix int64) string {
	d := time.Since(time.Unix(unix, 0))
	switch {
	case d < time.Minute:
		return "az önce"
	case d < time.Hour:
		return fmt.Sprintf("%d dk önce", int(d.Minutes()))
	case d < 24*time.Hour:
		return fmt.Sprintf("%d saat önce", int(d.Hours()))
	default:
		return fmt.Sprintf("%d gün önce", int(d.Hours())/24)
	}
}

var codeExpiryUnix atomic.Int64
var origEditProc uintptr

// chatEditProc subclasses the chat input so Enter sends the message.
func chatEditProc(hwnd uintptr, m uint32, wParam, lParam uintptr) uintptr {
	if m == 0x0087 { // WM_GETDLGCODE: want Enter/chars
		return 0x0004 | 0x0080 // DLGC_WANTALLKEYS | DLGC_WANTCHARS
	}
	if m == 0x0102 && wParam == 0x0D { // WM_CHAR, Enter
		sendChat()
		return 0
	}
	r, _, _ := callWindowProc.Call(origEditProc, hwnd, uintptr(m), wParam, lParam)
	return r
}

func logCrash(where string) {
	if r := recover(); r != nil {
		base, err := os.UserConfigDir()
		if err == nil && base != "" {
			dir := filepath.Join(base, "RemoteSupport")
			_ = os.MkdirAll(dir, 0700)
			if f, e := os.OpenFile(filepath.Join(dir, "crash.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600); e == nil {
				fmt.Fprintf(f, "%s PANIC in %s: %v\n%s\n\n", time.Now().Format(time.RFC3339), where, r, debug.Stack())
				f.Close()
			}
		}
		setStatus("● Bir hata yakalandı ve kaydedildi (crash.log).")
	}
}

func auditLog(event string) {
	base, err := os.UserConfigDir()
	if err != nil || base == "" {
		return
	}
	dir := filepath.Join(base, "RemoteSupport")
	_ = os.MkdirAll(dir, 0700)
	f, err := os.OpenFile(filepath.Join(dir, "audit.log"), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s\t%s\n", time.Now().Format("2006-01-02 15:04:05"), event)
}

func paintShell(hdc uintptr) {
	var rc rect
	getClientRect.Call(state.hwnd, uintptr(unsafe.Pointer(&rc)))
	w := int(rc.Right - rc.Left)
	h := int(rc.Bottom - rc.Top)
	if w <= 0 || h <= 0 {
		return
	}

	state.mu.Lock()
	mode := state.mode
	status := state.statusText
	state.mu.Unlock()
	viewer.mu.RLock()
	connected := viewer.active
	viewer.mu.RUnlock()

	// ---- Canvas: subtle vertical navy gradient ----
	vGradient(hdc, 0, 0, w, h, uiBgColor, uiBgColor2, 22)

	paintTopBar(hdc, w, connected, status)
	paintSidebar(hdc, h)

	contentW := w - contentX - gutter

	switch {
	case connected:
		paintConnectedChrome(hdc, w, h)
	case mode == 0:
		paintHome(hdc, w, h, contentW)
	case mode == 1 && capturing.Load():
		paintAgentSharingBanner(hdc, w)
		if idleWarn.Load() {
			paintText(hdc, "Oturum boşta — sürdürmek için 'Açık Kal'", contentX+164, 214, w-contentX-gutter-164, 40, uiButtonFont, uiWarn, txVLeft)
		}
		paintChatPanel(hdc, computeChatGeom(w, h))
	case mode == 1:
		paintPageHeader(hdc, "Destek Al", "Bu kodu destek verecek kişiye iletin.")
		paintText(hdc, "BAĞLANTI KODUNUZ", contentX, 300, 300, 18, uiLabelFont, uiMutedColor, txVLeft)
		paintCard(hdc, contentX, 322, 782, 128, uiEditColor, uiBorderColor, 16)
		if code := getActiveCode(); code != "" && code != "------" {
			drawQR(hdc, buildJoinLink(code), contentX, 478, 150)
			paintText(hdc, "KAREKODU TARATIN VEYA LİNKİ PAYLAŞIN", contentX+166, 486, 470, 18, uiLabelFont, uiAccentColor, txVLeft)
			paintText(hdc, "Karşı taraf telefon kamerasıyla tarayabilir ya da linki uygulamaya yapıştırabilir.", contentX+166, 510, 470, 44, uiBodyFont, uiMutedColor, txWrap)
		} else {
			paintText(hdc, "Kod oluşturulduğunda burada görünür ve otomatik paylaşılır.", contentX, 470, 782, 20, uiBodyFont, uiFaintColor, txVLeft)
		}
		if exp := codeExpiryUnix.Load(); exp > 0 {
			rem := exp - time.Now().Unix()
			if rem < 0 {
				rem = 0
			}
			var ccol uint32 = uiCyanColor
			label := fmt.Sprintf("Kalan süre  %02d:%02d", rem/60, rem%60)
			if rem == 0 {
				label = "Kod süresi doldu — Geri dönüp tekrar başlatın"
				ccol = uiDanger
			}
			paintText(hdc, label, contentX, 300, 782, 18, uiLabelFont, ccol, txVRight)
		}
	case mode == 2:
		paintPageHeader(hdc, "Destek Ver", "Karşı bilgisayarın kodunu ya da nexdesk:// bağlantısını girin.")
		paintText(hdc, "BAĞLANTI KODU", contentX, 326, 300, 18, uiLabelFont, uiMutedColor, txVLeft)
		paintText(hdc, "Kod yalnızca karşı tarafın onayıyla bağlantı kurar.", contentX, 436, 782, 20, uiBodyFont, uiFaintColor, txVLeft)
	case mode == 10:
		paintSettings(hdc, w)
	case mode == 11:
		paintAbout(hdc, w)
	}

	paintFooter(hdc, w, h, connected)
}

// paintTopBar draws the product header: logo, wordmark, and either the feature
// chips (idle) or a live session pill (connected).
func paintTopBar(hdc uintptr, w int, connected bool, status string) {
	fillBand(hdc, 0, 0, w, headerH, rgb(uiBarColor))
	fillBand(hdc, 0, headerH-1, w, 1, rgb(uiBorderColor))

	// Embedded product logo on its own plate, then the wordmark + tagline.
	paintGlow(hdc, 20, 15, 56, 56, brandAccent(), 14)
	drawLogoPlate(hdc, 20, 15, 56, 56, 14)

	paintText(hdc, strings.ToUpper(brandName()), 88, 16, 430, 26, uiBrandFont, uiTextColor, txVLeft)
	paintText(hdc, brandTagline(), 89, 46, 470, 22, uiBodyFont, uiMutedColor, txVLeft)

	if connected {
		// Session identity + live indicator, right-aligned (leaves room for the
		// red disconnect button that layoutUI places at the far right).
		px := w - 470
		if px > 540 {
			paintCard(hdc, px, 22, 240, 42, uiPanelColor, uiBorderColor, 12)
			paintDot(hdc, px+22, 43, 5, uiSuccess)
			paintText(hdc, "Bağlı", px+38, 22, 60, 42, uiButtonFont, uiTextColor, txVLeft)
			_, sas := getConnInfo()
			info := "Doğrulama —"
			if sas != "" {
				info = "SAS " + sas
			}
			paintText(hdc, info, px+92, 22, 138, 42, uiSmallFont, uiCyanColor, txEnd)
		}
		if idleWarn.Load() {
			paintText(hdc, "Oturum boşta kaldı", w-690, 22, 300, 42, uiButtonFont, uiWarn, txVRight)
		}
		return
	}

	// Feature chips, right-anchored so they track the window width.
	chips := []struct{ icon, title, sub string }{
		{"✓", "Güvenli Bağlantı", "Uçtan uca şifreleme"},
		{"ϟ", "Yüksek Performans", "Düşük gecikme"},
		{"▣", "Çoklu Monitör", "Tüm ekranlara erişim"},
		{"⚙", "Kolay Kullanım", "Herkes için tasarlandı"},
	}
	chipW := 172
	groupW := chipW * len(chips)
	gx := w - gutter - groupW
	if gx < 560 {
		return // small window: keep the header uncluttered
	}
	for i, c := range chips {
		x := gx + i*chipW
		if i > 0 {
			fillBand(hdc, x-6, 24, 1, 38, rgb(uiBorderColor))
		}
		paintRoundPanel(hdc, x, 24, 36, 36, uiPanelHi, 10)
		paintText(hdc, c.icon, x, 24, 36, 36, uiIconFont, uiCyanColor, txMid)
		paintText(hdc, c.title, x+46, 23, chipW-58, 18, uiButtonFont, uiTextColor, txEnd)
		paintText(hdc, c.sub, x+46, 42, chipW-58, 16, uiSmallFont, uiMutedColor, txEnd)
	}
}

// paintSidebar draws the left navigation rail with the active-page indicator.
func paintSidebar(hdc uintptr, h int) {
	navTop := headerH
	navH := h - headerH - footerH
	fillBand(hdc, 0, navTop, navW, navH, rgb(uiNavColor))
	fillBand(hdc, navW-1, navTop, 1, navH, rgb(uiBorderColor))

	page := sidebarPage.Load()
	items := []struct {
		label, icon string
		page        int32
	}{
		{"Ana Sayfa", "⌂", 0},
		{"Bağlantılar", "↔", 1},
		{"Ayarlar", "⚙", 2},
		{"Hakkında", "ⓘ", 3},
	}
	iy := navTop + 16
	for _, it := range items {
		active := page == it.page
		var col, icol uint32 = uiMutedColor, uiFaintColor
		if active {
			paintRoundPanel(hdc, 10, iy, navW-20, 44, uiPanelHi, 10)
			fillBand(hdc, 12, iy+9, 3, 26, rgb(uiAccentColor))
			col = uiTextColor
			icol = uiAccentColor
		}
		paintText(hdc, it.icon, 24, iy, 28, 44, uiIconFont, icol, txMid)
		paintText(hdc, it.label, 58, iy, navW-66, 44, uiBodyFont, col, txVLeft)
		iy += 52
	}

	paintText(hdc, strings.ToUpper(brandName()), 22, h-footerH-44, navW-30, 16, uiLabelFont, uiFaintColor, txVLeft)
	paintText(hdc, "Sürüm 1.1.0", 22, h-footerH-26, navW-30, 16, uiSmallFont, uiFaintColor, txVLeft)
}

func paintPageHeader(hdc uintptr, title, subtitle string) {
	paintText(hdc, title, contentX, 104, 640, 34, uiHeaderFont, uiTextColor, txVLeft)
	paintText(hdc, subtitle, contentX+2, 146, 720, 22, uiBodyFont, uiMutedColor, txVLeft)
}

// paintHome draws the two primary action cards (backgrounds are the owner-drawn
// homeGet/homeGive buttons) and a "Son Bağlantılar" panel below them.
func paintHome(hdc uintptr, w, h, contentW int) {
	paintPageHeader(hdc, "Uzaktan Destek", "Bilgisayarınızı güvenli bir bağlantıyla yönetin veya destek alın.")

	// "Son Bağlantılar" panel.
	recentY := 400
	recentH := h - footerH - recentY - 16
	if recentH <= 90 {
		return
	}
	paintCard(hdc, contentX, recentY, contentW, recentH, uiPanelColor, uiBorderColor, 14)
	paintText(hdc, "SON BAĞLANTILAR", contentX+22, recentY+18, 300, 18, uiLabelFont, uiMutedColor, txVLeft)
	fillBand(hdc, contentX+22, recentY+44, contentW-44, 1, rgb(uiBorderColor))
	items := recentSnapshot()
	if len(items) == 0 {
		paintText(hdc, "Henüz bağlantı geçmişi yok.", contentX+22, recentY+58, contentW-44, 22, uiSubtitleFont, uiFaintColor, txVLeft)
		paintText(hdc, "Kurduğunuz oturumlar burada listelenecek.", contentX+22, recentY+84, contentW-44, 20, uiBodyFont, uiFaintColor, txVLeft)
		return
	}
	rowH := 40
	y := recentY + 54
	maxRows := (recentY + recentH - 12 - y) / rowH
	if maxRows < 1 {
		maxRows = 1
	}
	if len(items) > maxRows {
		items = items[:maxRows]
	}
	for _, it := range items {
		paintDot(hdc, contentX+30, y+rowH/2, 4, uiSuccess)
		paintText(hdc, it.Role, contentX+48, y, 220, rowH, uiSubtitleFont, uiTextColor, txVLeft)
		paintText(hdc, "Kod "+formatCode(it.Code), contentX+280, y, 220, rowH, uiBodyFont, uiMutedColor, txVLeft)
		paintText(hdc, relativeTime(it.At), contentX+48, y, contentW-70, rowH, uiSmallFont, uiFaintColor, txVRight)
		y += rowH
	}
}

// paintConnectedChrome draws the remote-desktop workspace frame: a toolbar
// surface behind the screen/quality controls and a stats strip under the viewer.
func paintConnectedChrome(hdc uintptr, w, h int) {
	// Toolbar surface behind the monitor/resolution/action buttons.
	paintCard(hdc, contentX, 98, w-contentX-gutter, 58, uiPanelColor, uiBorderColor, 12)
	hostLbl := "UZAK MASAÜSTÜ"
	if h := getRemoteHost(); h != "" {
		hostLbl = "UZAK MASAÜSTÜ — " + h
	}
	paintText(hdc, hostLbl, contentX, 60, 600, 18, uiLabelFont, uiFaintColor, txVLeft)

	// Stats strip along the bottom of the viewer area (viewer sits at y=145,
	// height h-210 → its bottom is h-65; the footer starts at h-52).
	stripY := h - footerH - 13
	res := map[int32]string{0: "Otomatik", 1080: "1080p", 720: "720p", 480: "480p"}[captureMaxHeight.Load()]
	if res == "" {
		res = "Otomatik"
	}
	path, sas := getConnInfo()
	pathLabel := map[string]string{"direct": "Doğrudan bağlantı", "relay": "TURN üzerinden"}[path]
	if pathLabel == "" {
		pathLabel = "Yol belirleniyor…"
	}
	fps := fpsValue.Load()
	qCol := uint32(uiSuccess)
	qLabel := "İyi"
	if fps < 8 {
		qCol = uiDanger
		qLabel = "Zayıf"
	} else if fps < 18 {
		qCol = uiWarn
		qLabel = "Orta"
	}
	idleS := time.Now().Unix() - lastActivityUnix.Load()
	if idleS < 0 {
		idleS = 0
	}
	parts := []string{
		"Bağlantı: " + qLabel,
		"Süre: " + sessionElapsed(),
		fmt.Sprintf("Boşta: %02d:%02d", idleS/60, idleS%60),
		fmt.Sprintf("%d FPS", fpsValue.Load()),
		"Çözünürlük: " + res,
		"Kodek: H.264",
		pathLabel,
	}
	if sas != "" {
		parts = append(parts, "SAS: "+sas)
	}
	stats := strings.Join(parts, "     •     ")
	paintDot(hdc, contentX+12, stripY+6, 4, qCol)
	paintText(hdc, stats, contentX+24, stripY, w-contentX-gutter-24, 12, uiSmallFont, uiFaintColor, txVLeft)
	paintChatPanel(hdc, computeChatGeom(w, h))
}

func paintAgentSharingBanner(hdc uintptr, w int) {
	bw := w - contentX - gutter
	// Persistent, high-visibility "you are being viewed" banner (agent side).
	paintCard(hdc, contentX, 104, bw, 96, uiPanelHi, uiDanger, 16)
	paintDot(hdc, contentX+30, 152, 7, uiDanger)
	paintText(hdc, "Ekranınız şu anda paylaşılıyor", contentX+52, 118, bw-74, 26, uiTitleFont, uiTextColor, txVLeft)
	paintText(hdc, "Uzaktaki kişi ekranınızı görüyor ve fare/klavye kullanabilir. Bağlantıyı istediğiniz an kesebilirsiniz.", contentX+52, 150, bw-74, 22, uiBodyFont, uiMutedColor, txVLeft)
	_, sas := getConnInfo()
	if sas != "" {
		paintText(hdc, "Güvenlik doğrulama kodu (SAS): "+sas+"  —  karşı taraftakiyle birebir aynı olmalı.", contentX, 214, bw, 20, uiBodyFont, uiCyanColor, txVLeft)
	}
}

func paintSettings(hdc uintptr, w int) {
	paintPageHeader(hdc, "Ayarlar", "Bağlantı, görüntü ve çalışma tercihleri.")
	cw := w - contentX - gutter
	if cw > 1000 {
		cw = 1000
	}
	// A — signaling
	paintCard(hdc, contentX, 168, cw, 84, uiPanelColor, uiBorderColor, 14)
	paintText(hdc, "BAĞLANTI", contentX+24, 182, 300, 16, uiLabelFont, uiAccentColor, txVLeft)
	paintText(hdc, "İnternet Signaling — boş bırakılırsa LAN keşfi", contentX+24, 210, 300, 18, uiBodyFont, uiMutedColor, txVLeft)
	// B — TURN
	paintCard(hdc, contentX, 262, cw, 138, uiPanelColor, uiBorderColor, 14)
	paintText(hdc, "TURN SUNUCUSU — İSTEĞE BAĞLI", contentX+24, 276, 400, 16, uiLabelFont, uiAccentColor, txVLeft)
	paintText(hdc, "STUN yetmezse (symmetric NAT) relay olarak kullanılır.", contentX+24, 296, 520, 16, uiSmallFont, uiMutedColor, txVLeft)
	paintText(hdc, "Adres", contentX+24, 328, 70, 16, uiSmallFont, uiMutedColor, txVLeft)
	paintText(hdc, "Kullanıcı", contentX+24, 366, 70, 16, uiSmallFont, uiMutedColor, txVLeft)
	paintText(hdc, "Parola", 556, 366, 60, 16, uiSmallFont, uiMutedColor, txVLeft)
	// C — görüntü
	paintCard(hdc, contentX, 402, cw, 74, uiPanelColor, uiBorderColor, 14)
	paintText(hdc, "GÖRÜNTÜ", contentX+24, 416, 200, 16, uiLabelFont, uiAccentColor, txVLeft)
	paintText(hdc, "Kalite", 520, 416, 120, 16, uiSmallFont, uiMutedColor, txVLeft)
	paintText(hdc, "Maksimum yükseklik", 760, 416, 180, 16, uiSmallFont, uiMutedColor, txVLeft)
	// D — oturum güvenliği
	paintCard(hdc, contentX, 486, cw, 106, uiPanelColor, uiBorderColor, 14)
	paintText(hdc, "OTURUM GÜVENLİĞİ", contentX+24, 500, 260, 16, uiLabelFont, uiAccentColor, txVLeft)
	paintText(hdc, "Boşta kalma uyarısı", 520, 500, 180, 16, uiSmallFont, uiMutedColor, txVLeft)
	paintText(hdc, "Süre dolunca (varsayılan: açık kal)", 760, 500, 320, 16, uiSmallFont, uiMutedColor, txVLeft)
	paintText(hdc, "Ayarlar uygulama yeniden başlatıldığında korunur.", contentX, 662, cw, 18, uiBodyFont, uiFaintColor, txVLeft)
}

func paintAbout(hdc uintptr, w int) {
	paintPageHeader(hdc, "Hakkında", brandName()+" hakkında bilgi.")
	cw := w - contentX - gutter
	paintCard(hdc, contentX, 190, cw, 316, uiPanelColor, uiBorderColor, 16)
	paintGlow(hdc, contentX+30, 214, 96, 96, brandAccent(), 20)
	drawLogoPlate(hdc, contentX+30, 214, 96, 96, 18)
	paintText(hdc, brandName(), contentX+150, 224, 460, 34, uiHeaderFont, uiTextColor, txVLeft)
	paintText(hdc, brandTagline(), contentX+150, 264, 520, 24, uiBodyFont, uiMutedColor, txVLeft)
	fillBand(hdc, contentX+30, 330, cw-60, 1, rgb(uiBorderColor))
	paintText(hdc, "PROGRAM YAZARI", contentX+30, 346, 240, 18, uiLabelFont, brandAccent(), txVLeft)
	paintText(hdc, brandAuthor(), contentX+30, 370, 320, 30, uiSubtitleFont, uiTextColor, txVLeft)
	paintText(hdc, "Sürüm 1.1.0     •     © 2026", contentX+30, 420, 420, 22, uiBodyFont, uiMutedColor, txVLeft)
	paintText(hdc, "Uçtan uca şifreleme  •  Çoklu monitör  •  Ekran/dosya aktarımı  •  İşaretleme  •  Otomatik yeniden bağlanma", contentX+30, 452, cw-60, 22, uiBodyFont, uiMutedColor, txVLeft)
}

func paintFooter(hdc uintptr, w, h int, connected bool) {
	footerY := h - footerH
	fillBand(hdc, 0, footerY, w, footerH, rgb(uiBarColor))
	fillBand(hdc, 0, footerY, w, 1, rgb(uiBorderColor))
	var dotCol uint32 = uiFaintColor
	if connected {
		dotCol = uiSuccess
	}
	paintDot(hdc, 30, footerY+footerH/2, 5, dotCol)
	label := "Bağlantı Durumu: " + map[bool]string{true: "Aktif", false: "Hazır"}[connected]
	paintText(hdc, label, 44, footerY, 260, footerH, uiBodyFont, uiTextColor, txVLeft)
	paintText(hdc, "Program Yazarı: "+brandAuthor()+"  •  © 2026", w-360, footerY, 336, footerH, uiBodyFont, uiMutedColor, txVRight)
}

func createControl(parent uintptr, class, text string, style uint32, x, y, w, h, id int) uintptr {
	if class == "BUTTON" {
		style |= 0x0000000B // BS_OWNERDRAW
	}
	r, _, _ := createWindow.Call(
		0,
		uintptr(unsafe.Pointer(utf16ptr(class))),
		uintptr(unsafe.Pointer(utf16ptr(text))),
		uintptr(style|0x40000000|0x10000000|0x00010000), // + WS_TABSTOP
		uintptr(x), uintptr(y), uintptr(w), uintptr(h),
		parent, uintptr(id), moduleHandle(), 0,
	)
	switch class {
	case "BUTTON":
		setControlFont(r, uiButtonFont)
	case "EDIT":
		setControlFont(r, uiEditFont)
	case "STATIC":
		if text == appTitle {
			setControlFont(r, uiHeaderFont)
		} else if text == "Güvenli uzaktan destek" {
			setControlFont(r, uiSubtitleFont)
		} else if len(text) == 6 {
			setControlFont(r, uiCodeFont)
		} else {
			setControlFont(r, uiBodyFont)
		}
	}
	return r
}

func moduleHandle() uintptr {
	r, _, _ := getModule.Call(0)
	return r
}

// appIcon loads the embedded NexDesk icon (RT_GROUP_ICON id 1 from
// rsrc_windows_amd64.syso) at the given size; 0 if the resource is missing.
func appIcon(size int) uintptr {
	const imageIcon, lrShared = 1, 0x8000
	r, _, _ := loadImage.Call(moduleHandle(), 1, imageIcon, uintptr(size), uintptr(size), lrShared)
	return r
}

func hide(hwnd uintptr) {
	if hwnd != 0 {
		showWindow.Call(hwnd, 0) // SW_HIDE
	}
}

func show(hwnd uintptr) {
	if hwnd != 0 {
		showWindow.Call(hwnd, 5) // SW_SHOW
	}
}

func clearChildren() {
	clearResolutionButtons()
	for _, h := range []uintptr{
		state.homeGet, state.homeGive, state.codeLabel, state.remoteEdit, state.action, state.copy, state.back, state.fileSend, state.fullscreenButton, state.settingsEndpoint, state.settingsQuality, state.settingsResolution, state.settingsSave, state.settingsReset, state.settingsIdle, state.settingsIdleAction, state.settingsTurnURL, state.settingsTurnUser, state.settingsTurnPass, state.elevate, state.clipSend, state.clipGet, state.chatInput, state.chatSend, state.stayOpen, state.actionsBtn,
	} {
		hide(h)
	}
}

func home() {
	clearChildren()
	state.mode = 0
	setStatus("Bir işlem seç.")
	layoutUI()
}

func clearResolutionButtons() {
	state.mu.Lock()
	buttons := append([]uintptr(nil), state.resolutionButtons...)
	state.resolutionButtons = nil
	state.mu.Unlock()
	for _, h := range buttons {
		if h != 0 {
			destroyWindow.Call(h)
		}
	}
}

func supportMode() {
	startEmbeddedSignaling()
	clearChildren()
	state.mode = 1
	hide(state.homeGet)
	hide(state.homeGive)

	setText(state.action, "Kod oluşturuluyor...")
	show(state.codeLabel)
	show(state.action)
	show(state.copy)
	show(state.back)
	layoutUI()

	setStatus("Sunucuya bağlanılıyor...")
	go startTarget()
}

func giveMode() {
	clearChildren()
	state.mode = 2
	hide(state.homeGet)
	hide(state.homeGive)

	show(state.remoteEdit)
	show(state.action)
	show(state.back)
	setText(state.action, "BAĞLAN")
	layoutUI()
	setStatus("Karşı bilgisayarın kodunu ya da paylaşılan bağlantıyı girin.")
}

func startTarget() {
	userStopped.Store(false)
	everConnected.Store(false)
	reconnecting.Store(false)
	captureMaxHeight.Store(0)
	activeTargetMonitorMu.Lock()
	activeTargetMonitor = capture.Monitor{}
	activeTargetMonitorOK = false
	activeTargetMonitorMu.Unlock()
	activeMonitor.Store(0)
	remoteMonitorsMu.Lock()
	remoteMonitors = nil
	remoteMonitorsMu.Unlock()
	ctx, cancel := context.WithCancel(context.Background())
	state.mu.Lock()
	state.cancel = cancel
	state.ctx = ctx
	state.mu.Unlock()

	c, err := clientsignaling.Dial(ctx, signalingEndpoint())
	if err != nil {
		setStatus("● Sunucuya bağlanılamadı: " + err.Error())
		return
	}

	code, expires, err := c.Create(ctx)
	if err != nil {
		_ = c.Close(context.Background())
		setStatus("● Kod oluşturulamadı: " + err.Error())
		return
	}

	state.mu.Lock()
	state.sig = c
	state.mu.Unlock()

	setCode(formatCode(code))
	setActiveCode(code)
	codeExpiryUnix.Store(time.Now().Unix() + int64(expires))
	auditLog("Kod oluşturuldu")
	setText(state.action, "Kod hazır")
	setStatus(fmt.Sprintf("● Hazır  •  Kod yaklaşık %d saniye geçerli", expires))

	go func() {
		defer logCrash("codeCountdown")
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for range t.C {
			if capturing.Load() || state.mode != 1 {
				return
			}
			if state.hwnd != 0 {
				invalidateRect.Call(state.hwnd, 0, 0)
			}
			if time.Now().Unix() >= codeExpiryUnix.Load() {
				return
			}
		}
	}()
	go targetLoop(ctx, c)
}

func targetLoop(ctx context.Context, c *clientsignaling.Client) {
	defer logCrash("targetLoop")
	for {
		msg, err := c.Read(ctx)
		if err != nil {
			setStatus("● Bağlantı kapandı.")
			return
		}

		switch msg.Type {
		case "peer_joined":
			messageBeep.Call(0x00000040) // MB_ICONASTERISK
			if state.hwnd != 0 {
				flashWindow.Call(state.hwnd, 1)
			}
			auditLog("Bağlantı isteği alındı")
			ok := askApproval(msg.Code)
			if err := c.Approve(ctx, ok, ""); err != nil {
				setStatus("● Onay gönderilemedi: " + err.Error())
				return
			}
			if !ok {
				auditLog("İstek reddedildi")
				setStatus("Bağlantı isteği reddedildi.")
				continue
			}

			peer, err := newPeer(ctx, c, true)
			if err != nil {
				setStatus("● WebRTC başlatılamadı: " + err.Error())
				return
			}
			state.mu.Lock()
			state.peer = peer
			state.mu.Unlock()

			peer.SetControlHandler(func(msg string) { defer logCrash("control"); handleRemoteInput(peer, msg) })
			peer.SetFileHandler(func(d []byte) { defer logCrash("file"); handleRemoteFile(d) })
			setStatus("● İstek onaylandı. Güvenli bağlantı kuruluyor...")
			startCapture(peer, ctx)
			go watchPeer(peer)
		case "signal":
			state.mu.Lock()
			p := state.peer
			state.mu.Unlock()
			sig := webrtcpeer.Signal{Kind: msg.Kind, Payload: msg.Payload}
			switch sig.Kind {
			case "offer":
				if p == nil || peerDead(p) {
					p = targetRebuild(ctx, c)
					if p == nil {
						continue
					}
				}
				answer, err := p.AcceptOffer(ctx, sig)
				if err != nil {
					setStatus("● Teklif işlenemedi: " + err.Error())
					return
				}
				if err := c.Signal(ctx, answer.Kind, answer.Payload); err != nil {
					setStatus("● Cevap gönderilemedi: " + err.Error())
					return
				}
			case "candidate":
				if p == nil {
					continue
				}
				if err := p.AddSignal(sig); err != nil {
					setStatus("● ICE adayı işlenemedi: " + err.Error())
				}
			}
		case "closed":
			setStatus("Bağlantı sonlandırıldı.")
			return
		}
	}
}

func startOperator(code string) {
	defer logCrash("startOperator")
	setActiveCode(code)
	userStopped.Store(false)
	everConnected.Store(false)
	reconnecting.Store(false)
	activeTargetMonitorMu.Lock()
	activeTargetMonitor = capture.Monitor{}
	activeTargetMonitorOK = false
	activeTargetMonitorMu.Unlock()
	activeMonitor.Store(0)
	remoteMonitorsMu.Lock()
	remoteMonitors = nil
	remoteMonitorsMu.Unlock()
	ctx, cancel := context.WithCancel(context.Background())
	state.mu.Lock()
	state.cancel = cancel
	state.ctx = ctx
	state.mu.Unlock()

	ep := signalingEndpoint()
	if ov := getOpEndpoint(); ov != "" {
		ep = ov
	}
	c, err := clientsignaling.Dial(ctx, ep)
	if err != nil {
		setStatus("● Sunucuya bağlanılamadı: " + err.Error())
		return
	}

	if err := c.Join(ctx, strings.TrimSpace(code)); err != nil {
		_ = c.Close(context.Background())
		setStatus("● Kod kabul edilmedi: " + err.Error())
		return
	}

	state.mu.Lock()
	state.sig = c
	state.mu.Unlock()
	auditLog("Bağlantı isteği gönderildi")
	setStatus("● Bağlantı isteği gönderildi. Karşı tarafın onayı bekleniyor...")

	for {
		msg, err := c.Read(ctx)
		if err != nil {
			setStatus("● Bağlantı kurulamadı: " + err.Error())
			return
		}

		switch msg.Type {
		case "approved":
			peer, err := newPeer(ctx, c, true)
			if err != nil {
				setStatus("● WebRTC başlatılamadı: " + err.Error())
				return
			}
			state.mu.Lock()
			state.peer = peer
			state.mu.Unlock()

			peer.SetScreenHandler(setViewerFrame)
			peer.SetControlHandler(func(msg string) { defer logCrash("control"); handleRemoteInput(peer, msg) })
			peer.SetFileHandler(func(d []byte) { defer logCrash("file"); handleRemoteFile(d) })

			if err := peer.CreateControl(); err != nil {
				setStatus("● Kontrol kanalı açılamadı: " + err.Error())
				return
			}
			if err := peer.CreateFile(); err != nil {
				setStatus("● Dosya kanalı açılamadı: " + err.Error())
				return
			}
			if err := peer.CreateScreen(); err != nil {
				setStatus("● Ekran kanalı açılamadı: " + err.Error())
				return
			}

			offer, err := peer.Offer(ctx)
			if err != nil {
				setStatus("● WebRTC teklifi oluşturulamadı: " + err.Error())
				return
			}
			if err := c.Signal(ctx, offer.Kind, offer.Payload); err != nil {
				setStatus("● WebRTC teklifi gönderilemedi: " + err.Error())
				return
			}

			setStatus("● Onaylandı. Güvenli WebRTC bağlantısı kuruluyor...")
			go watchPeer(peer)

		case "signal":
			state.mu.Lock()
			p := state.peer
			state.mu.Unlock()
			if p == nil {
				continue
			}
			sig := webrtcpeer.Signal{Kind: msg.Kind, Payload: msg.Payload}
			if err := p.AddSignal(sig); err != nil {
				setStatus("● WebRTC sinyali işlenemedi: " + err.Error())
			}
		case "rejected":
			setStatus("Karşı taraf bağlantı isteğini reddetti.")
			return
		case "closed":
			setStatus("Bağlantı sonlandırıldı.")
			return
		}
	}
}

func newPeer(ctx context.Context, c *clientsignaling.Client, approved bool) (*webrtcpeer.Peer, error) {
	_ = ctx
	cfg := currentSettings()
	ice := []webrtc.ICEServer{
		{URLs: []string{"stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"}},
	}
	if u := strings.TrimSpace(cfg.TurnURL); u != "" {
		srv := webrtc.ICEServer{URLs: []string{u}}
		if strings.TrimSpace(cfg.TurnUser) != "" {
			srv.Username = cfg.TurnUser
			srv.Credential = cfg.TurnPass
			srv.CredentialType = webrtc.ICECredentialTypePassword
		}
		ice = append(ice, srv)
	}
	return webrtcpeer.NewWithConfig(approved, webrtc.Configuration{ICEServers: ice}, func(sctx context.Context, sig webrtcpeer.Signal) error {
		return c.Signal(sctx, sig.Kind, sig.Payload)
	})
}

func showConnectedView() {
	hide(state.action)
	hide(state.back)
	hide(state.remoteEdit)
	showViewer()
	show(state.fileSend)
	layoutUI()
	resizeViewer()
}

func watchPeer(peer *webrtcpeer.Peer) {
	defer logCrash("watchPeer")
	ticker := time.NewTicker(250 * time.Millisecond)
	defer ticker.Stop()

	announced := false
	for range ticker.C {
		st := peer.ConnectionState()
		switch st {
		case webrtc.PeerConnectionStateConnected:
			if announced {
				continue
			}
			announced = true
			everConnected.Store(true)
			reconnecting.Store(false)
			if host, err := os.Hostname(); err == nil {
				_ = peer.SendControlText("HELLO:" + host)
			}
			if state.mode == 1 {
				sendRemoteMonitorList(peer)
			}
			showConnectedView()
			setConnInfo(peer.PathKind(), "")
			if v, ok := peer.FingerprintSAS(getActiveCode()); ok {
				setConnInfo("", v)
			}
			startSessionStats(peer)
			recRole := "Destek verildi"
			if state.mode == 1 {
				recRole = "Destek alındı"
			}
			addRecent(recRole, getActiveCode())
			auditLog("Bağlandı: " + recRole)
			setStatus("● BAĞLANDI  •  Güvenli WebRTC bağlantısı aktif")
			_ = peer.SendPing()
		case webrtc.PeerConnectionStateFailed, webrtc.PeerConnectionStateClosed, webrtc.PeerConnectionStateDisconnected:
			if announced {
				onPeerDropped(state.mode)
			} else {
				setStatus("● WebRTC bağlantısı kapandı: " + st.String())
			}
			return
		}
	}
}

func askApproval(code string) bool {
	title := utf16ptr(brandName())
	text := utf16ptr(fmt.Sprintf(
		"Bir bilgisayar bu destek koduyla bağlanmak istiyor.\r\n\r\nKod: %s\r\n\r\nBağlantıya izin verilsin mi?",
		formatCode(code),
	))
	r, _, _ := messageBox.Call(state.hwnd, uintptr(unsafe.Pointer(text)), uintptr(unsafe.Pointer(title)), 0x00000004|0x00000020)
	return r == 6 // IDYES
}

func formatCode(code string) string {
	code = strings.ReplaceAll(strings.TrimSpace(code), " ", "")
	switch len(code) {
	case 6:
		return code[:3] + " " + code[3:]
	case 10:
		return code[:3] + " " + code[3:6] + " " + code[6:]
	default:
		return code
	}
}

func copyCode() {
	code := strings.ReplaceAll(getText(state.codeLabel), " ", "")
	if code == "" {
		return
	}
	if copyToClipboard(code) {
		setStatus("Kod panoya kopyalandı: " + formatCode(code))
	} else {
		setStatus("Kod: " + formatCode(code) + "  • Karşı bilgisayarda bu kodu girin.")
	}
}

func copyToClipboard(s string) bool {
	if r, _, _ := openClipboard.Call(state.hwnd); r == 0 {
		return false
	}
	defer closeClipboard.Call()
	emptyClipboard.Call()

	data := syscall.StringToUTF16(s)
	size := uintptr(len(data) * 2)
	h, _, _ := globalAlloc.Call(0x0002, size) // GMEM_MOVEABLE
	if h == 0 {
		return false
	}
	p, _, _ := globalLock.Call(h)
	if p == 0 {
		return false
	}
	copyBytes(unsafe.Pointer(p), unsafe.Pointer(&data[0]), int(size))
	globalUnlock.Call(h)
	if r, _, _ := setClipboardData.Call(13, h); r == 0 { // CF_UNICODETEXT
		return false
	}
	return true
}

func copyBytes(dst, src unsafe.Pointer, n int) {
	d := unsafe.Slice((*byte)(dst), n)
	s := unsafe.Slice((*byte)(src), n)
	copy(d, s)
}

func readClipboardText() (string, bool) {
	if state.hwnd == 0 {
		return "", false
	}
	if r, _, _ := openClipboard.Call(state.hwnd); r == 0 {
		return "", false
	}
	defer closeClipboard.Call()
	h, _, _ := user32.NewProc("GetClipboardData").Call(13) // CF_UNICODETEXT
	if h == 0 {
		return "", false
	}
	p, _, _ := globalLock.Call(h)
	if p == 0 {
		return "", false
	}
	defer globalUnlock.Call(h)
	// CF_UNICODETEXT is UTF-16 and NUL terminated. Bound the read so a
	// malformed clipboard cannot make us scan unbounded memory.
	const maxClipboardRunes = 32768
	buf := unsafe.Slice((*uint16)(unsafe.Pointer(p)), maxClipboardRunes)
	n := 0
	for n < len(buf) && buf[n] != 0 {
		n++
	}
	return syscall.UTF16ToString(buf[:n]), true
}

func sendClipboardToPeer(peer *webrtcpeer.Peer) bool {
	text, ok := readClipboardText()
	if !ok {
		return false
	}
	data := []byte(text)
	if len(data) > 48*1024 {
		setStatus("● Pano metni 48 KB sınırını aşıyor.")
		return false
	}
	payload := base64.StdEncoding.EncodeToString(data)
	return peer.SendControlText("CLIP:"+payload) == nil
}

func requestRemoteClipboard(peer *webrtcpeer.Peer) bool {
	return peer.SendControlText("CLIP_REQ") == nil
}

func normalizeCode(s string) string {
	s = strings.ReplaceAll(strings.TrimSpace(s), " ", "")
	if len(s) < 6 || len(s) > 14 {
		return ""
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return ""
		}
	}
	return s
}

func clearMonitorButtons() {
	state.mu.Lock()
	buttons := append([]uintptr(nil), state.monitorButtons...)
	state.monitorButtons = nil
	state.mu.Unlock()
	for _, h := range buttons {
		if h != 0 {
			destroyWindow.Call(h)
		}
	}
}

func updateMonitorButtons(count int) {
	if count < 0 {
		count = 0
	}
	clearMonitorButtons()
	state.mu.Lock()
	oldRes := append([]uintptr(nil), state.resolutionButtons...)
	state.resolutionButtons = nil
	state.mu.Unlock()
	for _, h := range oldRes {
		if h != 0 {
			destroyWindow.Call(h)
		}
	}

	buttons := make([]uintptr, 0, count)
	const buttonW = 112
	const buttonH = 30
	const gap = 8
	for i := 0; i < count; i++ {
		x := 178 + i*(buttonW+gap)
		h := createControl(state.hwnd, "BUTTON", fmt.Sprintf("Monitör %d", i+1), 0x00000001, x, 102, buttonW, buttonH, ID_MONITOR_BASE+i)
		buttons = append(buttons, h)
	}
	state.mu.Lock()
	state.monitorButtons = buttons
	state.mu.Unlock()

	res := []struct {
		name string
		id   int
	}{
		{"Otomatik", ID_RES_ORIGINAL}, {"1080p", ID_RES_1080P}, {"720p", ID_RES_720P}, {"480p", ID_RES_480P},
	}
	resButtons := make([]uintptr, 0, len(res))
	startX := 178
	if count > 0 {
		startX += count * (buttonW + gap)
	}
	for i, r := range res {
		x := startX + i*82
		resButtons = append(resButtons, createControl(state.hwnd, "BUTTON", r.name, 0x00000001, x, 102, 76, 30, r.id))
	}
	state.mu.Lock()
	state.resolutionButtons = resButtons
	state.mu.Unlock()
	showResolutionControls(!fullscreen.Load())
	resizeViewer()
}

func selectMonitor(index int) {
	remoteMonitorsMu.RLock()
	count := len(remoteMonitors)
	remoteMonitorsMu.RUnlock()
	if index < 0 || index >= count {
		return
	}
	activeMonitor.Store(int32(index))
	state.mu.Lock()
	peer := state.peer
	state.mu.Unlock()
	if peer != nil {
		_ = peer.SendControlText(fmt.Sprintf("MONITOR:%d", index))
	}
	viewer.mu.Lock()
	viewer.pixels = nil
	viewer.width = 0
	viewer.height = 0
	viewer.fit = true
	viewer.zoom = 1
	viewer.panX = 0
	viewer.panY = 0
	viewer.clearNeeded = true
	viewer.mu.Unlock()
	if viewer.hwnd != 0 {
		invalidateRect.Call(viewer.hwnd, 0, 0)
	}
	setStatus(fmt.Sprintf("● Monitör %d/%d isteniyor...", index+1, count))
}

func populateSettingsControls() {
	cfg := currentSettings()
	if state.settingsEndpoint != 0 {
		setText(state.settingsEndpoint, cfg.SignalingURL)
	}
	if state.settingsQuality != 0 {
		idx := 0
		if cfg.Quality == 76 {
			idx = 1
		}
		sendMessage.Call(state.settingsQuality, 0x014E, uintptr(idx), 0)
	}
	if state.settingsResolution != 0 {
		idx := 0
		switch cfg.MaxHeight {
		case 1080:
			idx = 1
		case 720:
			idx = 2
		case 480:
			idx = 3
		}
		sendMessage.Call(state.settingsResolution, 0x014E, uintptr(idx), 0)
	}
	if state.settingsIdle != 0 {
		idx := 0
		switch cfg.IdleWarnMin {
		case 10:
			idx = 1
		case 20:
			idx = 2
		case 30:
			idx = 3
		}
		sendMessage.Call(state.settingsIdle, 0x014E, uintptr(idx), 0)
	}
	if state.settingsIdleAction != 0 {
		idx := 0
		if cfg.IdleClose {
			idx = 1
		}
		sendMessage.Call(state.settingsIdleAction, 0x014E, uintptr(idx), 0)
	}
	if state.settingsTurnURL != 0 {
		setText(state.settingsTurnURL, cfg.TurnURL)
	}
	if state.settingsTurnUser != 0 {
		setText(state.settingsTurnUser, cfg.TurnUser)
	}
	if state.settingsTurnPass != 0 {
		setText(state.settingsTurnPass, cfg.TurnPass)
	}
}

func showSettings() {
	clearChildren()
	state.mu.Lock()
	state.mode = 10
	state.mu.Unlock()
	populateSettingsControls()
	layoutUI()
	invalidateRect.Call(state.hwnd, 0, 1)
}

func showAbout() {
	clearChildren()
	state.mu.Lock()
	state.mode = 11
	state.mu.Unlock()
	layoutUI()
	invalidateRect.Call(state.hwnd, 0, 1)
}

func saveSettingsFromUI() {
	cfg := currentSettings()
	if state.settingsEndpoint != 0 {
		cfg.SignalingURL = strings.TrimSpace(getText(state.settingsEndpoint))
	}
	if state.settingsQuality != 0 {
		r, _, _ := sendMessage.Call(state.settingsQuality, 0x0147, 0, 0)
		if r == 1 {
			cfg.Quality = 76
		} else {
			cfg.Quality = 88
		}
	}
	if state.settingsResolution != 0 {
		r, _, _ := sendMessage.Call(state.settingsResolution, 0x0147, 0, 0)
		switch r {
		case 1:
			cfg.MaxHeight = 1080
		case 2:
			cfg.MaxHeight = 720
		case 3:
			cfg.MaxHeight = 480
		default:
			cfg.MaxHeight = 0
		}
	}
	if state.settingsIdle != 0 {
		r, _, _ := sendMessage.Call(state.settingsIdle, 0x0147, 0, 0)
		switch r {
		case 1:
			cfg.IdleWarnMin = 10
		case 2:
			cfg.IdleWarnMin = 20
		case 3:
			cfg.IdleWarnMin = 30
		default:
			cfg.IdleWarnMin = 0
		}
	}
	if state.settingsIdleAction != 0 {
		r, _, _ := sendMessage.Call(state.settingsIdleAction, 0x0147, 0, 0)
		cfg.IdleClose = r == 1
	}
	if state.settingsTurnURL != 0 {
		cfg.TurnURL = strings.TrimSpace(getText(state.settingsTurnURL))
	}
	if state.settingsTurnUser != 0 {
		cfg.TurnUser = strings.TrimSpace(getText(state.settingsTurnUser))
	}
	if state.settingsTurnPass != 0 {
		cfg.TurnPass = getText(state.settingsTurnPass)
	}
	settingsMu.Lock()
	appCfg = cfg
	settingsMu.Unlock()
	saveSettings()
	captureMaxHeight.Store(int32(cfg.MaxHeight))
	setStatus("Ayarlar kaydedildi.")
	invalidateRect.Call(state.hwnd, 0, 1)
}

func resetSettingsUI() {
	settingsMu.Lock()
	appCfg = appSettings{Quality: 88, MaxHeight: 0, InputEnabled: true, IdleWarnMin: 10, IdleClose: false}
	settingsMu.Unlock()
	saveSettings()
	populateSettingsControls()
	captureMaxHeight.Store(0)
	setStatus("Ayarlar varsayılan değerlere döndürüldü.")
}

// curtainProc paints the agent privacy curtain (black + a short notice).
func curtainProc(hwnd uintptr, m uint32, wParam, lParam uintptr) uintptr {
	if m == 0x000F { // WM_PAINT
		var ps paintStruct
		hdc, _, _ := beginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		if hdc != 0 {
			var rc rect
			getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
			bb, _, _ := getStockObject.Call(4)
			fillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), bb)
			setBkMode.Call(hdc, 1)
			setTextColor.Call(hdc, rgb(0x8AA0B8))
			old, _, _ := selectObject.Call(hdc, uiSubtitleFont)
			wt := utf16ptr("Gizlilik modu etkin — ekranınız yalnızca yetkili destek görevlisine görünür")
			drawText.Call(hdc, uintptr(unsafe.Pointer(wt)), ^uintptr(0), uintptr(unsafe.Pointer(&rc)), uintptr(dtCenter|dtVCenter|dtSingleLine))
			selectObject.Call(hdc, old)
			endPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		}
		return 0
	}
	r, _, _ := defWindowProc.Call(hwnd, uintptr(m), wParam, lParam)
	return r
}

func ensureCurtain() {
	if curtainHwnd != 0 {
		return
	}
	class := utf16ptr("RSCurtain")
	bb, _, _ := getStockObject.Call(4)
	wc := wndclassex{CbSize: uint32(unsafe.Sizeof(wndclassex{})), LpfnWndProc: syscall.NewCallback(curtainProc), HInstance: moduleHandle(), HbrBackground: bb, LpszClassName: class}
	registerClassEx.Call(uintptr(unsafe.Pointer(&wc)))
	x := systemMetric(76)
	y := systemMetric(77)
	w := systemMetric(78)
	h := systemMetric(79)
	hwnd, _, _ := createWindow.Call(0x00000008|0x00000080|0x08000000, uintptr(unsafe.Pointer(class)), 0, 0x80000000,
		uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, moduleHandle(), 0)
	curtainHwnd = hwnd
	if hwnd != 0 {
		setWinDisplayAff.Call(hwnd, 0x00000011) // WDA_EXCLUDEFROMCAPTURE: hidden from screen capture
	}
}

func showCurtain() {
	ensureCurtain()
	if curtainHwnd != 0 {
		showWindow.Call(curtainHwnd, 8) // SW_SHOWNA
		invalidateRect.Call(curtainHwnd, 0, 1)
	}
}

func hideCurtain() {
	if curtainHwnd != 0 {
		showWindow.Call(curtainHwnd, 0)
	}
}

// clearPrivacy removes any curtain and unblocks local input. Called on
// disconnect so the agent user can never be left locked out.
func clearPrivacy() {
	if state.hwnd != 0 {
		postMessage.Call(state.hwnd, WM_APP_CURTAIN, 0, 0)
	}
	blockInput.Call(0)
	remoteCurtainOn.Store(false)
	remoteLockOn.Store(false)
}

// ---- Screen annotation (operator marks the agent screen) ----
type annotSegN struct{ x1, y1, x2, y2 float64 }
type annotSeg struct {
	x1, y1, x2, y2 int
	at             time.Time
}

var annotateMode atomic.Bool
var annotDrawing bool
var annotLastX, annotLastY float64
var annotHwnd uintptr
var annotMu sync.Mutex
var annotStrokes []annotSeg
var annotPending []annotSegN
var annotFadeOnce sync.Once

func sendAnnot(x1, y1, x2, y2 float64) {
	state.mu.Lock()
	pr := state.peer
	state.mu.Unlock()
	if pr != nil {
		_ = pr.SendControlText(fmt.Sprintf("ANNOT:%.4f,%.4f,%.4f,%.4f", x1, y1, x2, y2))
	}
}

func annotProc(hwnd uintptr, m uint32, wParam, lParam uintptr) uintptr {
	if m == 0x000F { // WM_PAINT
		var ps paintStruct
		hdc, _, _ := beginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		if hdc != 0 {
			var rc rect
			getClientRect.Call(hwnd, uintptr(unsafe.Pointer(&rc)))
			bb, _, _ := getStockObject.Call(4)
			fillRect.Call(hdc, uintptr(unsafe.Pointer(&rc)), bb) // black = colorkey = transparent
			pen, _, _ := createPen.Call(0, 4, rgb(0xFF3B30))
			old, _, _ := selectObject.Call(hdc, pen)
			annotMu.Lock()
			strokes := append([]annotSeg(nil), annotStrokes...)
			annotMu.Unlock()
			for _, sg := range strokes {
				moveToEx.Call(hdc, uintptr(sg.x1), uintptr(sg.y1), 0)
				lineTo.Call(hdc, uintptr(sg.x2), uintptr(sg.y2))
			}
			selectObject.Call(hdc, old)
			deleteObject.Call(pen)
			endPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		}
		return 0
	}
	r, _, _ := defWindowProc.Call(hwnd, uintptr(m), wParam, lParam)
	return r
}

func ensureAnnotOverlay() {
	if annotHwnd != 0 {
		return
	}
	class := utf16ptr("RSAnnot")
	bb, _, _ := getStockObject.Call(4)
	wc := wndclassex{CbSize: uint32(unsafe.Sizeof(wndclassex{})), LpfnWndProc: syscall.NewCallback(annotProc), HInstance: moduleHandle(), HbrBackground: bb, LpszClassName: class}
	registerClassEx.Call(uintptr(unsafe.Pointer(&wc)))
	x := systemMetric(76)
	y := systemMetric(77)
	w := systemMetric(78)
	h := systemMetric(79)
	ex := uintptr(0x80000 | 0x20 | 0x8 | 0x80 | 0x08000000) // LAYERED|TRANSPARENT|TOPMOST|TOOLWINDOW|NOACTIVATE
	hwnd, _, _ := createWindow.Call(ex, uintptr(unsafe.Pointer(class)), 0, 0x80000000, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, moduleHandle(), 0)
	annotHwnd = hwnd
	if hwnd != 0 {
		setLayeredWinAttr.Call(hwnd, 0x00000000, 0, 0x1) // LWA_COLORKEY: black transparent
	}
}

func drainAnnot() {
	mon, ok := remoteTargetMonitor()
	if !ok {
		annotMu.Lock()
		annotPending = nil
		annotMu.Unlock()
		return
	}
	vl := int(systemMetric(76))
	vt := int(systemMetric(77))
	now := time.Now()
	annotMu.Lock()
	pend := annotPending
	annotPending = nil
	for _, pp := range pend {
		annotStrokes = append(annotStrokes, annotSeg{
			x1: mon.X + int(pp.x1*float64(mon.Width)) - vl, y1: mon.Y + int(pp.y1*float64(mon.Height)) - vt,
			x2: mon.X + int(pp.x2*float64(mon.Width)) - vl, y2: mon.Y + int(pp.y2*float64(mon.Height)) - vt, at: now})
	}
	if len(annotStrokes) > 2000 {
		annotStrokes = annotStrokes[len(annotStrokes)-2000:]
	}
	annotMu.Unlock()
	ensureAnnotOverlay()
	if annotHwnd != 0 {
		showWindow.Call(annotHwnd, 8)
		invalidateRect.Call(annotHwnd, 0, 1)
	}
	startAnnotFade()
}

func clearAnnot() {
	annotMu.Lock()
	annotStrokes = nil
	annotMu.Unlock()
	if annotHwnd != 0 {
		invalidateRect.Call(annotHwnd, 0, 1)
	}
}

func startAnnotFade() {
	annotFadeOnce.Do(func() {
		go func() {
			defer logCrash("annotFade")
			t := time.NewTicker(500 * time.Millisecond)
			defer t.Stop()
			for range t.C {
				annotMu.Lock()
				before := len(annotStrokes)
				cutoff := time.Now().Add(-4 * time.Second)
				kept := annotStrokes[:0]
				for _, sg := range annotStrokes {
					if sg.at.After(cutoff) {
						kept = append(kept, sg)
					}
				}
				annotStrokes = kept
				changed := len(annotStrokes) != before
				annotMu.Unlock()
				if changed && annotHwnd != 0 {
					invalidateRect.Call(annotHwnd, 0, 1)
				}
			}
		}()
	})
}

// ---------------------------------------------------------------------------
// Branding (white-label) + embedded logo
// ---------------------------------------------------------------------------

//go:embed assets/logo.png
var logoPNG []byte

type brandCfg struct {
	Name     string `json:"name"`
	Tagline  string `json:"tagline"`
	Author   string `json:"author"`
	Accent   string `json:"accent"`
	LogoPath string `json:"logo_path"`
}

var (
	brandMu       sync.RWMutex
	brandNameV    = "NexDesk"
	brandTaglineV = "Uzaktan destek, daha kolay"
	brandAuthorV  = "Hasan Güler"
	brandAccentV  = uint32(uiAccentColor)
	brandLogoPath string
)

func brandName() string    { brandMu.RLock(); defer brandMu.RUnlock(); return brandNameV }
func brandTagline() string { brandMu.RLock(); defer brandMu.RUnlock(); return brandTaglineV }
func brandAuthor() string  { brandMu.RLock(); defer brandMu.RUnlock(); return brandAuthorV }
func brandAccent() uint32  { brandMu.RLock(); defer brandMu.RUnlock(); return brandAccentV }

func brandingPath() string {
	base, err := os.UserConfigDir()
	if err != nil {
		base = os.TempDir()
	}
	return filepath.Join(base, "RemoteSupport", "branding.json")
}

// loadBranding lets an integrator white-label the app by dropping a branding.json
// next to the settings (name, tagline, author, accent hex, optional logo path).
func loadBranding() {
	data, err := os.ReadFile(brandingPath())
	if err != nil {
		return
	}
	var b brandCfg
	if json.Unmarshal(data, &b) != nil {
		return
	}
	brandMu.Lock()
	if strings.TrimSpace(b.Name) != "" {
		brandNameV = strings.TrimSpace(b.Name)
	}
	if strings.TrimSpace(b.Tagline) != "" {
		brandTaglineV = strings.TrimSpace(b.Tagline)
	}
	if strings.TrimSpace(b.Author) != "" {
		brandAuthorV = strings.TrimSpace(b.Author)
	}
	if c, ok := parseHexColor(b.Accent); ok {
		brandAccentV = c
	}
	brandLogoPath = strings.TrimSpace(b.LogoPath)
	brandMu.Unlock()
}

func parseHexColor(s string) (uint32, bool) {
	s = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(s), "#"))
	if len(s) != 6 {
		return 0, false
	}
	var v uint32
	for _, r := range s {
		var d uint32
		switch {
		case r >= '0' && r <= '9':
			d = uint32(r - '0')
		case r >= 'a' && r <= 'f':
			d = uint32(r-'a') + 10
		case r >= 'A' && r <= 'F':
			d = uint32(r-'A') + 10
		default:
			return 0, false
		}
		v = v<<4 | d
	}
	return v, true
}

var (
	logoOnce  sync.Once
	logoPix   []byte
	logoW     int
	logoH     int
	logoPlate uint32 = 0x1D1C1D
)

func loadLogo() {
	logoOnce.Do(func() {
		var raw []byte
		brandMu.RLock()
		lp := brandLogoPath
		brandMu.RUnlock()
		if lp != "" {
			if d, err := os.ReadFile(lp); err == nil {
				raw = d
			}
		}
		if raw == nil {
			raw = logoPNG
		}
		img, err := png.Decode(bytes.NewReader(raw))
		if err != nil {
			return
		}
		b := img.Bounds()
		w, h := b.Dx(), b.Dy()
		if w <= 0 || h <= 0 {
			return
		}
		pix := make([]byte, w*h*4)
		for y := 0; y < h; y++ {
			for x := 0; x < w; x++ {
				r, g, bl, _ := img.At(b.Min.X+x, b.Min.Y+y).RGBA()
				i := (y*w + x) * 4
				pix[i+0] = byte(bl >> 8)
				pix[i+1] = byte(g >> 8)
				pix[i+2] = byte(r >> 8)
				pix[i+3] = 0
			}
		}
		cr, cg, cb, _ := img.At(b.Min.X+2, b.Min.Y+2).RGBA()
		logoPlate = (uint32(cr>>8) << 16) | (uint32(cg>>8) << 8) | uint32(cb>>8)
		logoPix, logoW, logoH = pix, w, h
	})
}

// drawLogoPlate paints a rounded plate the colour of the logo's own background
// and blits the logo aspect-fit + centred inside it, so any letterbox area blends
// seamlessly regardless of the surface behind it.
func drawLogoPlate(hdc uintptr, x, y, w, h, radius int) {
	loadLogo()
	paintRoundPanel(hdc, x, y, w, h, logoPlate, radius)
	if len(logoPix) == 0 || logoW == 0 || logoH == 0 {
		return
	}
	pad := 6
	aw, ah := w-pad*2, h-pad*2
	if aw <= 0 || ah <= 0 {
		return
	}
	dw, dh := aw, ah
	if logoW*ah > logoH*aw {
		dh = logoH * aw / logoW
	} else {
		dw = logoW * ah / logoH
	}
	dx := x + pad + (aw-dw)/2
	dy := y + pad + (ah-dh)/2
	bi := bitmapInfo{BmiHeader: bitmapInfoHeader{
		BiSize:        uint32(unsafe.Sizeof(bitmapInfoHeader{})),
		BiWidth:       int32(logoW),
		BiHeight:      -int32(logoH),
		BiPlanes:      1,
		BiBitCount:    32,
		BiCompression: 0,
	}}
	setStretchMode.Call(hdc, 4) // HALFTONE: smooth downscale
	stretchDIBits.Call(hdc,
		uintptr(dx), uintptr(dy), uintptr(dw), uintptr(dh),
		0, 0, uintptr(logoW), uintptr(logoH),
		uintptr(unsafe.Pointer(&logoPix[0])), uintptr(unsafe.Pointer(&bi)), 0, 0x00CC0020)
}

// ---------------------------------------------------------------------------
// Join link + QR code
// ---------------------------------------------------------------------------

func primaryLANIP() string {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err != nil {
		return ""
	}
	defer conn.Close()
	if ua, ok := conn.LocalAddr().(*net.UDPAddr); ok {
		return ua.IP.String()
	}
	return ""
}

// shareWSURL returns the ws:// endpoint an operator should dial to reach THIS
// target: the configured internet signaling if set, else this machine's LAN
// address on the embedded signaling port.
func shareWSURL() string {
	cfg := currentSettings()
	if v := strings.TrimSpace(cfg.SignalingURL); v != "" {
		return v
	}
	if ip := primaryLANIP(); ip != "" {
		return "ws://" + ip + ":8091/v1/ws"
	}
	return ""
}

var linkCacheMu sync.Mutex
var linkCacheCode, linkCacheVal string

func buildJoinLink(code string) string {
	code = strings.ReplaceAll(strings.TrimSpace(code), " ", "")
	linkCacheMu.Lock()
	defer linkCacheMu.Unlock()
	if code == linkCacheCode && linkCacheVal != "" {
		return linkCacheVal
	}
	v := url.Values{}
	if ws := shareWSURL(); ws != "" {
		v.Set("ws", ws)
	}
	v.Set("code", code)
	linkCacheCode = code
	linkCacheVal = "nexdesk://join?" + v.Encode()
	return linkCacheVal
}

// parseJoinInput accepts either a raw numeric code or a nexdesk://join link and
// returns the code plus an optional ws endpoint override.
func parseJoinInput(s string) (code, ws string) {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(strings.ToLower(s), "nexdesk://") {
		if u, err := url.Parse(s); err == nil {
			q := u.Query()
			return normalizeCode(q.Get("code")), strings.TrimSpace(q.Get("ws"))
		}
	}
	return normalizeCode(s), ""
}

var opEndpointMu sync.Mutex
var opEndpointOverride string

func setOpEndpoint(v string) { opEndpointMu.Lock(); opEndpointOverride = v; opEndpointMu.Unlock() }
func getOpEndpoint() string {
	opEndpointMu.Lock()
	defer opEndpointMu.Unlock()
	return opEndpointOverride
}

var (
	qrCacheMu  sync.Mutex
	qrCacheKey string
	qrCacheMat [][]bool
)

func qrMatrix(text string) [][]bool {
	qrCacheMu.Lock()
	defer qrCacheMu.Unlock()
	if text == qrCacheKey && qrCacheMat != nil {
		return qrCacheMat
	}
	m, _ := qrEncode(text, 0)
	qrCacheKey = text
	qrCacheMat = m
	return m
}

// drawQR paints a cached QR of text into a size×size box at (x,y). A 1px-per-
// module DIB is scaled up with a nearest-neighbour StretchBlt for crisp squares.
func drawQR(hdc uintptr, text string, x, y, size int) {
	mat := qrMatrix(text)
	n := len(mat)
	if n == 0 {
		return
	}
	quiet := 3
	dim := n + quiet*2
	paintRoundPanel(hdc, x, y, size, size, 0xFFFFFF, 8)
	pix := make([]byte, dim*dim*4)
	for i := range pix {
		pix[i] = 0xFF
	}
	for r := 0; r < n; r++ {
		for c := 0; c < n; c++ {
			if mat[r][c] {
				i := ((r+quiet)*dim + (c + quiet)) * 4
				pix[i+0], pix[i+1], pix[i+2] = 0, 0, 0
			}
		}
	}
	inner := size - 12
	bi := bitmapInfo{BmiHeader: bitmapInfoHeader{
		BiSize:        uint32(unsafe.Sizeof(bitmapInfoHeader{})),
		BiWidth:       int32(dim),
		BiHeight:      -int32(dim),
		BiPlanes:      1,
		BiBitCount:    32,
		BiCompression: 0,
	}}
	setStretchMode.Call(hdc, 3) // COLORONCOLOR: crisp modules
	stretchDIBits.Call(hdc,
		uintptr(x+6), uintptr(y+6), uintptr(inner), uintptr(inner),
		0, 0, uintptr(dim), uintptr(dim),
		uintptr(unsafe.Pointer(&pix[0])), uintptr(unsafe.Pointer(&bi)), 0, 0x00CC0020)
}

// ---------------------------------------------------------------------------
// Auto-reconnect
// ---------------------------------------------------------------------------

var (
	userStopped   atomic.Bool
	everConnected atomic.Bool
	reconnecting  atomic.Bool
)

func peerDead(p *webrtcpeer.Peer) bool {
	switch p.ConnectionState() {
	case webrtc.PeerConnectionStateFailed, webrtc.PeerConnectionStateClosed, webrtc.PeerConnectionStateDisconnected:
		return true
	}
	return false
}

func onPeerDropped(role int) {
	if userStopped.Load() || !everConnected.Load() {
		return
	}
	if role == 2 {
		setStatus("● Bağlantı koptu — otomatik yeniden bağlanılıyor…")
		go operatorReconnectLoop()
	} else {
		setStatus("● Bağlantı koptu — karşı tarafın yeniden bağlanması bekleniyor…")
	}
}

// operatorNegotiate builds a fresh peer and offer over the still-open signaling
// channel. Used both for the initial connect's retry and for auto-reconnect.
func operatorNegotiate(ctx context.Context, c *clientsignaling.Client) error {
	peer, err := newPeer(ctx, c, true)
	if err != nil {
		return err
	}
	peer.SetScreenHandler(setViewerFrame)
	peer.SetControlHandler(func(msg string) { defer logCrash("control"); handleRemoteInput(peer, msg) })
	peer.SetFileHandler(func(d []byte) { defer logCrash("file"); handleRemoteFile(d) })
	if err := peer.CreateControl(); err != nil {
		return err
	}
	if err := peer.CreateFile(); err != nil {
		return err
	}
	if err := peer.CreateScreen(); err != nil {
		return err
	}
	offer, err := peer.Offer(ctx)
	if err != nil {
		return err
	}
	state.mu.Lock()
	old := state.peer
	state.peer = peer
	state.mu.Unlock()
	if old != nil {
		_ = old.Close()
	}
	if err := c.Signal(ctx, offer.Kind, offer.Payload); err != nil {
		return err
	}
	go watchPeer(peer)
	return nil
}

func operatorReconnectLoop() {
	if !reconnecting.CompareAndSwap(false, true) {
		return
	}
	defer reconnecting.Store(false)
	for attempt := 1; attempt <= 6; attempt++ {
		if userStopped.Load() {
			return
		}
		time.Sleep(time.Duration(attempt) * time.Second)
		if userStopped.Load() {
			return
		}
		state.mu.Lock()
		ctx := state.ctx
		c := state.sig
		state.mu.Unlock()
		if ctx == nil || c == nil {
			setStatus("● Yeniden bağlanılamadı — elle yeniden bağlanın.")
			return
		}
		setStatus(fmt.Sprintf("● Yeniden bağlanılıyor… (deneme %d/6)", attempt))
		if err := operatorNegotiate(ctx, c); err != nil {
			continue
		}
		deadline := time.Now().Add(10 * time.Second)
		for time.Now().Before(deadline) {
			if userStopped.Load() {
				return
			}
			state.mu.Lock()
			p := state.peer
			state.mu.Unlock()
			if p != nil && p.ConnectionState() == webrtc.PeerConnectionStateConnected {
				return
			}
			time.Sleep(300 * time.Millisecond)
		}
	}
	setStatus("● Otomatik yeniden bağlanma başarısız. 'Bağlantıyı Kes' ile kapatıp yeniden deneyin.")
}

// targetRebuild recreates the target-side peer when a renegotiation offer arrives
// after a drop (auto-reconnect), mirroring the initial peer_joined setup.
func targetRebuild(ctx context.Context, c *clientsignaling.Client) *webrtcpeer.Peer {
	peer, err := newPeer(ctx, c, true)
	if err != nil {
		setStatus("● Yeniden bağlantı kurulamadı: " + err.Error())
		return nil
	}
	peer.SetControlHandler(func(msg string) { defer logCrash("control"); handleRemoteInput(peer, msg) })
	peer.SetFileHandler(func(d []byte) { defer logCrash("file"); handleRemoteFile(d) })
	state.mu.Lock()
	old := state.peer
	state.peer = peer
	state.mu.Unlock()
	if old != nil {
		_ = old.Close()
	}
	setStatus("● Karşı taraf yeniden bağlanıyor…")
	startCapture(peer, ctx)
	go watchPeer(peer)
	return peer
}

func gatherSysInfo() string {
	host, _ := os.Hostname()
	gb := func(b uint64) float64 { return float64(b) / (1 << 30) }
	var mse memoryStatusEx
	mse.Length = uint32(unsafe.Sizeof(mse))
	globalMemStatus.Call(uintptr(unsafe.Pointer(&mse)))
	var freeAvail, total, totalFree uint64
	getDiskFreeSpace.Call(uintptr(unsafe.Pointer(utf16ptr("C:\\"))), uintptr(unsafe.Pointer(&freeAvail)), uintptr(unsafe.Pointer(&total)), uintptr(unsafe.Pointer(&totalFree)))
	return fmt.Sprintf("Bilgisayar: %s\r\nSistem: %s / %s\r\nİşlemci çekirdeği: %d\r\nBellek: %.1f / %.1f GB boş\r\nDisk (C:): %.1f / %.1f GB boş",
		host, runtime.GOOS, runtime.GOARCH, runtime.NumCPU(), gb(mse.AvailPhys), gb(mse.TotalPhys), gb(totalFree), gb(total))
}

func showActionsMenu() {
	menu, _, _ := createPopupMenu.Call()
	if menu == 0 {
		return
	}
	defer destroyMenu.Call(menu)
	mi := func(m, flags, id uintptr, label string) {
		var p uintptr
		if label != "" {
			p = uintptr(unsafe.Pointer(utf16ptr(label)))
		}
		appendMenuW.Call(m, flags, id, p)
	}
	mi(menu, 0x0000, ID_FILE_SEND, "Dosya Gönder")
	mi(menu, 0x0000, ID_CLIP_SEND, "Panoyu Gönder")
	mi(menu, 0x0000, ID_CLIP_GET, "Panoyu Al")
	mi(menu, 0x0000, ID_SHOT, "Ekran Görüntüsü Kaydet (F12)")
	mi(menu, 0x0000, ID_SYSINFO, "Uzak Sistem Bilgisi")
	annotLabel := "İşaretleme Modu — Aç"
	if annotateMode.Load() {
		annotLabel = "İşaretleme Modu — Kapat"
	}
	mi(menu, 0x0000, ID_ANNOT, annotLabel)
	mi(menu, 0x0800, 0, "") // MF_SEPARATOR
	sub, _, _ := createPopupMenu.Call()
	if sub != 0 {
		mi(sub, 0x0000, ID_KEY_WIN, "Windows tuşu")
		mi(sub, 0x0000, ID_KEY_ALTTAB, "Alt + Tab")
		mi(sub, 0x0000, ID_KEY_ESC, "Esc")
		mi(menu, 0x0010, sub, "Özel Tuşlar") // MF_POPUP
	}
	mi(menu, 0x0800, 0, "") // MF_SEPARATOR
	curtainLabel := "Gizlilik Perdesi — Aç"
	if remoteCurtainOn.Load() {
		curtainLabel = "Gizlilik Perdesi — Kapat"
	}
	mi(menu, 0x0000, ID_CURTAIN, curtainLabel)
	lockLabel := "Yerel Girişi Kilitle"
	if remoteLockOn.Load() {
		lockLabel = "Yerel Giriş Kilidini Aç"
	}
	mi(menu, 0x0000, ID_LOCKINPUT, lockLabel)
	var pt point
	getCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	cmd, _, _ := trackPopupMenu.Call(menu, 0x0100, uintptr(pt.X), uintptr(pt.Y), 0, state.hwnd, 0) // TPM_RETURNCMD
	if cmd != 0 {
		onCommand(int(cmd))
	}
}

func onCommand(id int) {
	// Monitor buttons use ID_MONITOR_BASE+index. Bound the range tightly so
	// unrelated IDs in [2000,4000) (e.g. ID_FILE_SEND=3001) are NOT swallowed
	// here — that bug made "Dosya Gönder" silently call selectMonitor instead.
	if id >= ID_MONITOR_BASE && id < ID_MONITOR_BASE+64 {
		selectMonitor(id - ID_MONITOR_BASE)
		return
	}
	switch id {
	case ID_GET_SUPPORT:
		supportMode()
	case ID_GIVE_SUPPORT:
		giveMode()
	case ID_BACK:
		stopSession()
		home()
	case ID_COPY_CODE:
		copyCode()
	case ID_FILE_SEND:
		if path, ok := chooseFile(); ok {
			go sendFileToPeer(path)
		}
	case ID_RES_ORIGINAL:
		setRemoteResolution(0)
	case ID_RES_1080P:
		setRemoteResolution(1080)
	case ID_RES_720P:
		setRemoteResolution(720)
	case ID_RES_480P:
		setRemoteResolution(480)
	case ID_FULLSCREEN:
		toggleFullscreen()
	case ID_ELEVATE:
		restartAsAdmin()
	case ID_CLIP_SEND:
		state.mu.Lock()
		pr := state.peer
		state.mu.Unlock()
		if pr != nil {
			go func() {
				if sendClipboardToPeer(pr) {
					setStatus("● Pano karşı bilgisayara gönderildi.")
				}
			}()
		}
	case ID_CLIP_GET:
		state.mu.Lock()
		pr2 := state.peer
		state.mu.Unlock()
		if pr2 != nil {
			requestRemoteClipboard(pr2)
			setStatus("● Uzak pano istendi.")
		}
	case ID_CHAT_SEND:
		sendChat()
	case ID_STAY_OPEN:
		lastActivityUnix.Store(time.Now().Unix())
		idleWarn.Store(false)
		layoutUI()
		invalidateRect.Call(state.hwnd, 0, 0)
		setStatus("● Oturum açık tutuluyor.")
	case ID_ACTIONS:
		showActionsMenu()
	case ID_SHOT:
		go saveViewerScreenshot()
	case ID_SYSINFO:
		state.mu.Lock()
		ps := state.peer
		state.mu.Unlock()
		if ps != nil {
			ps.SendControlText("SYSINFO_REQ")
		}
	case ID_ANNOT:
		on := !annotateMode.Load()
		annotateMode.Store(on)
		if on {
			setStatus("● İşaretleme modu açık: ekranda sürükleyerek işaretleyin.")
		} else {
			state.mu.Lock()
			pa := state.peer
			state.mu.Unlock()
			if pa != nil {
				pa.SendControlText("ANNOT_CLEAR")
			}
			setStatus("● İşaretleme modu kapalı.")
		}
	case ID_KEY_WIN:
		sendRemoteKey("keydown", 0x5B)
		sendRemoteKey("keyup", 0x5B)
	case ID_KEY_ALTTAB:
		sendRemoteKey("keydown", 0x12)
		sendRemoteKey("keydown", 0x09)
		sendRemoteKey("keyup", 0x09)
		sendRemoteKey("keyup", 0x12)
	case ID_KEY_ESC:
		sendRemoteKey("keydown", 0x1B)
		sendRemoteKey("keyup", 0x1B)
	case ID_CURTAIN:
		on := !remoteCurtainOn.Load()
		remoteCurtainOn.Store(on)
		state.mu.Lock()
		pc := state.peer
		state.mu.Unlock()
		if pc != nil {
			if on {
				pc.SendControlText("CURTAIN:1")
			} else {
				pc.SendControlText("CURTAIN:0")
			}
		}
	case ID_LOCKINPUT:
		on := !remoteLockOn.Load()
		remoteLockOn.Store(on)
		state.mu.Lock()
		pl := state.peer
		state.mu.Unlock()
		if pl != nil {
			if on {
				pl.SendControlText("LOCKINPUT:1")
			} else {
				pl.SendControlText("LOCKINPUT:0")
			}
		}
	case ID_SETTINGS:
		sidebarPage.Store(2)
		showSettings()
		return
	case ID_ABOUT:
		sidebarPage.Store(3)
		showAbout()
		return
	case ID_SETTINGS_SAVE:
		saveSettingsFromUI()
		return
	case ID_SETTINGS_RESET:
		resetSettingsUI()
		return
	case ID_CONNECT:
		code, ws := parseJoinInput(getText(state.remoteEdit))
		if code == "" {
			setStatus("Bağlantı kodunu ya da nexdesk:// bağlantısını girin.")
			return
		}
		setOpEndpoint(ws)
		setText(state.action, "BAĞLANIYOR...")
		setStatus("● Bağlantı kodu doğrulanıyor...")
		go startOperator(code)
	case ID_SHARE_LINK:
		code := getActiveCode()
		if code == "" {
			setStatus("Önce bir bağlantı kodu oluşturulmalı.")
			return
		}
		if copyToClipboard(buildJoinLink(code)) {
			setStatus("● Bağlantı linki panoya kopyalandı — karşı tarafa iletin.")
		}
	}
}

func stopSession() {
	userStopped.Store(true)
	auditLog("Oturum kapatıldı")
	clearPrivacy()
	setRemoteHost("")
	annotateMode.Store(false)
	clearAnnot()
	resetConnInfo()
	resetChat()
	hideViewer()
	clearMonitorButtons()
	state.mu.Lock()
	cancel := state.cancel
	sig := state.sig
	peer := state.peer
	state.cancel = nil
	state.sig = nil
	state.peer = nil
	state.ctx = nil
	state.mu.Unlock()

	if cancel != nil {
		cancel()
	}
	if peer != nil {
		_ = peer.Close()
	}
	if sig != nil {
		_ = sig.Close(context.Background())
	}
}

type measureItemStruct struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemWidth  uint32
	ItemHeight uint32
	ItemData   uintptr
}

type drawItemStruct struct {
	CtlType    uint32
	CtlID      uint32
	ItemID     uint32
	ItemAction uint32
	ItemState  uint32
	HwndItem   uintptr
	HDC        uintptr
	RcItem     rect
	ItemData   uintptr
}

func buttonLabel(hwnd uintptr) string {
	buf := make([]uint16, 128)
	n, _, _ := getWindowText.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	if n == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf[:n])
}

func drawComboItem(dis *drawItemStruct) {
	if dis == nil || dis.HDC == 0 {
		return
	}
	hdc := dis.HDC
	r := dis.RcItem
	selected := dis.ItemState&0x0001 != 0 // ODS_SELECTED
	bg := uint32(uiEditColor)
	if selected {
		bg = uiAccentColor
	}
	brush, _, _ := createSolidBrush.Call(rgb(bg))
	if brush != 0 {
		fillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), brush)
		deleteObject.Call(brush)
	}
	if int32(dis.ItemID) >= 0 {
		var tb [256]uint16
		sendMessage.Call(dis.HwndItem, 0x0148, uintptr(dis.ItemID), uintptr(unsafe.Pointer(&tb[0]))) // CB_GETLBTEXT
		txt := syscall.UTF16ToString(tb[:])
		setBkMode.Call(hdc, 1)
		setTextColor.Call(hdc, rgb(uiTextColor))
		old, _, _ := selectObject.Call(hdc, uiBodyFont)
		rr := rect{Left: r.Left + 10, Top: r.Top, Right: r.Right - 6, Bottom: r.Bottom}
		drawText.Call(hdc, uintptr(unsafe.Pointer(utf16ptr(txt))), ^uintptr(0), uintptr(unsafe.Pointer(&rr)), uintptr(dtVCenter|dtSingleLine|dtEndEllip))
		selectObject.Call(hdc, old)
	}
}

func drawOwnerButton(dis *drawItemStruct) {
	if dis == nil || dis.HDC == 0 {
		return
	}
	hdc := dis.HDC
	r := dis.RcItem
	id := int(dis.CtlID)
	x, y := int(r.Left), int(r.Top)
	bw, bh := int(r.Right-r.Left), int(r.Bottom-r.Top)
	pressed := dis.ItemState&0x0001 != 0 // ODS_SELECTED
	hot := dis.ItemState&0x0040 != 0     // ODS_HOTLIGHT (mouse hover)
	viewer.mu.RLock()
	connected := viewer.active
	viewer.mu.RUnlock()

	// ---- Primary action cards (Destek Al / Destek Ver) ----
	if id == ID_GET_SUPPORT || id == ID_GIVE_SUPPORT {
		var fill, border uint32 = uiPanelColor, uiBorderColor
		if pressed || hot {
			fill = uiPanelHi
			border = uiAccentColor
		}
		paintCard(hdc, x, y, bw, bh, fill, border, 16)

		icon := "▣"
		title := "DESTEK VER"
		desc := "Karşı bilgisayara güvenli şekilde bağlanın."
		cta := "Bağlan  →"
		if id == ID_GET_SUPPORT {
			icon = "♙"
			title = "DESTEK AL"
			desc = "Bilgisayarınıza uzaktan bağlanılmasına izin verin."
			cta = "Kod Oluştur  →"
		}
		// Accent icon medallion with glow.
		paintGlow(hdc, x+24, y+24, 56, 56, uiAccentColor, 16)
		paintRoundPanel(hdc, x+24, y+24, 56, 56, uiAccentColor, 16)
		paintText(hdc, icon, x+24, y+24, 56, 56, uiHeaderFont, uiTextColor, txMid)

		paintText(hdc, title, x+96, y+28, bw-116, 26, uiTitleFont, uiTextColor, txVLeft)
		paintText(hdc, desc, x+96, y+58, bw-116, 44, uiBodyFont, uiMutedColor, txWrap)

		// CTA chip pinned to the bottom-left of the card.
		var chipCol uint32 = uiAccentColor
		if pressed {
			chipCol = uiAccentHi
		}
		paintText(hdc, cta, x+26, y+bh-40, bw-52, 22, uiButtonFont, chipCol, txVLeft)
		return
	}

	// ---- Regular buttons: pill styling by role ----
	text := buttonLabel(dis.HwndItem)
	font := uiButtonFont
	var fg uint32 = uiTextColor
	radius := 12

	var fill, border uint32
	switch {
	case id == ID_CONNECT:
		// Primary filled accent pill (faux gradient: accent body + lighter cap).
		fill, border = uiAccentColor, uiAccentColor
		if pressed {
			fill, border = uiAccentDim, uiAccentDim
		}
		fg = 0xFFFFFF
		font = uiSubtitleFont
		paintCard(hdc, x, y, bw, bh, fill, border, radius)
		if !pressed && bh > 10 {
			paintRoundPanel(hdc, x+2, y+2, bw-4, bh/2, mixHex(uiAccentColor, uiAccentHi, 0.5), radius)
		}
		paintText(hdc, text, x+10, y, bw-20, bh, font, fg, txMid|txEnd)
		return
	case id == ID_BACK && (connected || capturing.Load()):
		// Destructive: disconnect.
		fill, border, fg = uiDanger, uiDanger, 0xFFFFFF
		if pressed {
			fill, border = mixHex(uiDanger, 0x000000, 0.15), uiDanger
		}
		font = uiButtonFont
	case id == ID_COPY_CODE:
		fill, border = uiPanelHi, uiBorderColor
		fg = uiAccentColor
		if pressed {
			fill = uiPanelColor
		}
	case id == ID_STAY_OPEN:
		fill, border = uiSuccess, uiSuccess
		fg = 0xFFFFFF
		if pressed {
			fill, border = mixHex(uiSuccess, 0x000000, 0.15), uiSuccess
		}
	case id == ID_CHAT_SEND:
		fill, border = uiAccentColor, uiAccentColor
		fg = 0xFFFFFF
		if pressed {
			fill, border = uiAccentDim, uiAccentDim
		}
	case id == ID_ELEVATE:
		fill, border = uiPanelColor, uiAccentColor
		fg = uiAccentHi
		if pressed {
			fill = uiPanelHi
		}
	default:
		// Back (idle), file send, fullscreen, monitor & resolution pills.
		fill, border = uiPanelHi, uiBorderColor
		fg = uiTextColor
		if hot && !pressed {
			border = uiAccentColor
		}
		if pressed {
			fill, border = uiAccentColor, uiAccentColor
			fg = 0xFFFFFF
		}
	}

	paintCard(hdc, x, y, bw, bh, fill, border, radius)
	paintText(hdc, text, x+10, y, bw-20, bh, font, fg, txMid|txEnd)
}

func wndProc(hwnd uintptr, m uint32, wParam, lParam uintptr) uintptr {
	switch m {
	case 0x0014: // WM_ERASEBKGND
		return 1
	case 0x0002: // WM_DESTROY
		stopSession()
		postQuit.Call(0)
		return 0
	case 0x0138: // WM_CTLCOLORSTATIC
		hdc := wParam
		// The only prominent static is the connection-code label; give it the
		// input-field surface so it reads as the code box painted behind it.
		setTextColor.Call(hdc, rgb(uiTextColor))
		setBkColor.Call(hdc, rgb(uiEditColor))
		setBkMode.Call(hdc, 1) // TRANSPARENT
		return uiEditBrush
	case 0x0133: // WM_CTLCOLOREDIT
		hdc := wParam
		setTextColor.Call(hdc, rgb(uiTextColor))
		setBkColor.Call(hdc, rgb(uiEditColor)) // fill the field dark (missing before -> stayed white)
		setBkMode.Call(hdc, 2)                 // OPAQUE
		return uiEditBrush
	case 0x0135: // WM_CTLCOLORBTN
		hdc := wParam
		setTextColor.Call(hdc, rgb(uiTextColor))
		setBkMode.Call(hdc, 1)
		return uiPanelBrush
	case 0x0134: // WM_CTLCOLORLISTBOX (combo dropdown)
		hdc := wParam
		setTextColor.Call(hdc, rgb(uiTextColor))
		setBkColor.Call(hdc, rgb(uiEditColor))
		setBkMode.Call(hdc, 2)
		return uiEditBrush
	case 0x002C: // WM_MEASUREITEM
		mis := (*measureItemStruct)(unsafe.Pointer(lParam))
		if mis != nil {
			mis.ItemHeight = 26
		}
		return 1
	case 0x002B: // WM_DRAWITEM
		dis := (*drawItemStruct)(unsafe.Pointer(lParam))
		if dis != nil && dis.CtlType == 4 { // ODT_BUTTON
			drawOwnerButton(dis)
			return 1
		}
		if dis != nil && dis.CtlType == 3 { // ODT_COMBOBOX
			drawComboItem(dis)
			return 1
		}
		return 0
	case 0x0202: // WM_LBUTTONUP
		x := int(int16(lParam & 0xffff))
		y := int(int16((lParam >> 16) & 0xffff))
		// Left navigation rows: painted at y = 102 + 52*i, height 44 (see paintSidebar).
		if x >= 0 && x < navW && y >= 96 {
			switch {
			case y >= 96 && y < 148:
				sidebarPage.Store(0)
				home()
				return 0
			case y >= 148 && y < 200:
				sidebarPage.Store(1)
				return 0
			case y >= 200 && y < 252:
				sidebarPage.Store(2)
				showSettings()
				return 0
			case y >= 252 && y < 304:
				sidebarPage.Store(3)
				showAbout()
				return 0
			}
		}
	case 0x0111: // WM_COMMAND
		onCommand(int(wParam & 0xffff))
		return 0
	case WM_APP_MONITORS:
		count := int(wParam)
		updateMonitorButtons(count)
		setStatus(fmt.Sprintf("● Uzak bilgisayarda %d monitör bulundu", count))
		return 0
	case WM_APP_IDLE:
		layoutUI()
		invalidateRect.Call(hwnd, 0, 0)
		return 0
	case WM_APP_CURTAIN:
		if wParam != 0 {
			showCurtain()
		} else {
			hideCurtain()
		}
		return 0
	case WM_APP_ANNOT:
		if wParam != 0 {
			clearAnnot()
		} else {
			drainAnnot()
		}
		return 0
	case WM_APP_IDLE_CLOSE:
		stopSession()
		home()
		setStatus("● Oturum boşta kalma nedeniyle kapatıldı.")
		return 0
	case 0x0005: // WM_SIZE
		layoutUI()
		resizeViewer()
		invalidateRect.Call(hwnd, 0, 1) // repaint whole shell; erase is suppressed so stale paint lingers otherwise
		return 0
	case 0x000F: // WM_PAINT
		var ps paintStruct
		hdc, _, _ := beginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		if hdc != 0 {
			paintShell(hdc)
			endPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		}
		return 0
	}
	r, _, _ := defWindowProc.Call(hwnd, uintptr(m), wParam, lParam)
	return r
}

func addComboItems(hwnd uintptr, items ...string) {
	for _, item := range items {
		sendMessage.Call(hwnd, 0x0143, 0, uintptr(unsafe.Pointer(utf16ptr(item))))
	}
}

func main() {
	runtime.LockOSThread()
	loadSettings()
	loadBranding()
	loadRecent()
	initUITheme()
	loadLogo()

	class := utf16ptr(windowClass)
	wc := wndclassex{
		CbSize:        uint32(unsafe.Sizeof(wndclassex{})),
		LpfnWndProc:   syscall.NewCallback(wndProc),
		HInstance:     moduleHandle(),
		HCursor:       func() uintptr { r, _, _ := loadCursor.Call(0, 32512); return r }(),
		HbrBackground: 0, // parent paints the background in WM_PAINT
		LpszClassName: class,
		HIcon:         appIcon(32),
		HIconSm:       appIcon(16),
	}
	registerClass.Call(uintptr(unsafe.Pointer(&wc)))

	hwnd, _, _ := createWindow.Call(
		0,
		uintptr(unsafe.Pointer(class)),
		uintptr(unsafe.Pointer(utf16ptr(brandName()))),
		0x00CF0000|0x02000000, // WS_CLIPCHILDREN
		200, 120, windowWidth, windowHeight,
		0, 0, moduleHandle(), 0,
	)
	if hwnd == 0 {
		return
	}
	state.hwnd = hwnd
	registerViewerClass()
	createViewer(hwnd)
	hideViewer()

	state.header = createControl(hwnd, "STATIC", appTitle, 0x00000000, 40, 30, 650, 45, 0)
	state.subtitle = createControl(hwnd, "STATIC", "Güvenli uzaktan destek", 0x00000000, 40, 72, 650, 28, 0)
	state.status = createControl(hwnd, "STATIC", "Bir işlem seç.", 0, 40, 585, 900, 32, 0)

	getSupport := createControl(hwnd, "BUTTON", "DESTEK ALIYORUM", 0x00000001, 90, 205, 380, 100, ID_GET_SUPPORT)
	giveSupport := createControl(hwnd, "BUTTON", "DESTEK VERİYORUM", 0x00000001, 510, 205, 380, 100, ID_GIVE_SUPPORT)
	state.homeGet = getSupport
	state.homeGive = giveSupport
	state.action = createControl(hwnd, "BUTTON", "BAĞLAN", 0x00000001, 330, 365, 320, 58, ID_CONNECT)
	state.copy = createControl(hwnd, "BUTTON", "Kodu kopyala", 0x00000001, 665, 365, 180, 58, ID_COPY_CODE)
	state.shareLink = createControl(hwnd, "BUTTON", "Bağlantı Linki", 0x00000001, 0, 0, 10, 10, ID_SHARE_LINK)
	hide(state.shareLink)
	state.back = createControl(hwnd, "BUTTON", "← Geri", 0x00000001, 90, 365, 180, 58, ID_BACK)
	state.fileSend = createControl(hwnd, "BUTTON", "Dosya Gönder", 0x00000001, 760, 14, 100, 30, ID_FILE_SEND)
	state.fullscreenButton = createControl(hwnd, "BUTTON", "Tam Ekran", 0x00000001, 865, 14, 95, 30, ID_FULLSCREEN)
	state.clipSend = createControl(hwnd, "BUTTON", "Pano Gönder", 0x00000001, 620, 14, 130, 30, ID_CLIP_SEND)
	state.clipGet = createControl(hwnd, "BUTTON", "Pano Al", 0x00000001, 500, 14, 110, 30, ID_CLIP_GET)
	state.elevate = createControl(hwnd, "BUTTON", "Yönetici olarak yeniden başlat", 0x00000001, 700, 108, 260, 40, ID_ELEVATE)
	state.chatInput = createControl(hwnd, "EDIT", "", 0x00000080, 0, 0, 10, 10, 0)
	state.chatSend = createControl(hwnd, "BUTTON", "Gönder", 0x00000001, 0, 0, 10, 10, ID_CHAT_SEND)
	origEditProc, _, _ = setWindowLongPtr.Call(state.chatInput, ^uintptr(3), syscall.NewCallback(chatEditProc))
	state.stayOpen = createControl(hwnd, "BUTTON", "Açık Kal", 0x00000001, 0, 0, 10, 10, ID_STAY_OPEN)
	hide(state.stayOpen)
	state.actionsBtn = createControl(hwnd, "BUTTON", "İşlemler  ▾", 0x00000001, 0, 0, 10, 10, ID_ACTIONS)
	hide(state.actionsBtn)
	hide(state.fileSend)
	hide(state.fullscreenButton)
	hide(state.clipSend)
	hide(state.clipGet)
	hide(state.elevate)
	hide(state.chatInput)
	hide(state.chatSend)

	state.codeLabel = createControl(hwnd, "STATIC", newCode(), 0x00000001|0x00000200|0x00000080, 250, 190, 480, 90, 0)
	state.remoteEdit = createControl(hwnd, "EDIT", "", 0x00000001|0x00002000, 250, 190, 480, 58, ID_REMOTE_CODE)

	state.settingsEndpoint = createControl(hwnd, "EDIT", "", 0x00000080, 520, 235, 520, 44, 0) // ES_AUTOHSCROLL (metin/URL)
	state.settingsTurnURL = createControl(hwnd, "EDIT", "", 0x00000080, 284, 306, 664, 30, 0)
	state.settingsTurnUser = createControl(hwnd, "EDIT", "", 0x00000080, 284, 344, 250, 30, 0)
	state.settingsTurnPass = createControl(hwnd, "EDIT", "", 0x00000080, 622, 344, 326, 30, 0)
	state.settingsQuality = createControl(hwnd, "COMBOBOX", "", 0x0003|0x0010|0x0200, 520, 335, 180, 240, 0)
	state.settingsResolution = createControl(hwnd, "COMBOBOX", "", 0x0003|0x0010|0x0200, 760, 335, 180, 240, 0)
	addComboItems(state.settingsQuality, "Yüksek", "Dengeli")
	addComboItems(state.settingsResolution, "Otomatik", "1920 × 1080", "1280 × 720", "854 × 480")
	state.settingsIdle = createControl(hwnd, "COMBOBOX", "", 0x0003|0x0010|0x0200, 520, 490, 180, 240, 0)
	state.settingsIdleAction = createControl(hwnd, "COMBOBOX", "", 0x0003|0x0010|0x0200, 760, 490, 260, 240, 0)
	addComboItems(state.settingsIdle, "Kapalı", "10 dk", "20 dk", "30 dk")
	addComboItems(state.settingsIdleAction, "Açık kal", "Bağlantıyı kes")
	state.settingsSave = createControl(hwnd, "BUTTON", "Ayarları Kaydet", 0x00000001, 520, 500, 180, 44, ID_SETTINGS_SAVE)
	state.settingsReset = createControl(hwnd, "BUTTON", "Varsayılanlara Dön", 0x00000001, 720, 500, 220, 44, ID_SETTINGS_RESET)

	hide(state.action)
	hide(state.copy)
	hide(state.back)
	hide(state.codeLabel)
	hide(state.remoteEdit)
	hide(state.settingsEndpoint)
	hide(state.settingsQuality)
	hide(state.settingsResolution)
	hide(state.settingsSave)
	hide(state.settingsReset)
	hide(state.settingsIdle)
	hide(state.settingsIdleAction)
	hide(state.settingsTurnURL)
	hide(state.settingsTurnUser)
	hide(state.settingsTurnPass)

	state.mode = 0
	state.statusText = "Bir işlem seç."
	layoutUI()

	showWindow.Call(hwnd, 1)
	updateWindow.Call(hwnd)

	var m msg
	for {
		r, _, _ := getMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if d, _, _ := isDialogMessage.Call(state.hwnd, uintptr(unsafe.Pointer(&m))); d != 0 {
			continue
		}
		translateMsg.Call(uintptr(unsafe.Pointer(&m)))
		dispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
}

// Keep the package dependency explicit in this Windows-only client. The peer
// package exposes Pion's state values through ConnectionState().
var _ = webrtc.PeerConnectionStateConnected
var _ = destroyWindow
