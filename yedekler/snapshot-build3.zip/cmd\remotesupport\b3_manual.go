//go:build windows

package main

// Serverless handshake: the operator sends an "invite" (its WebRTC offer with
// all ICE candidates, compressed) over WhatsApp; the agent pastes it, approves,
// and sends back a "reply" (the answer). No signaling server is involved.

import (
	"bytes"
	"compress/flate"
	"context"
	"encoding/base64"
	"io"
	"net/url"
	"strings"
	"sync"
	"unsafe"

	webrtcpeer "github.com/eirahoutmoss/remotesupport/client/webrtc"
	"github.com/pion/webrtc/v4"
)

const (
	ID_MANUAL_OP    = 5230
	ID_MANUAL_AGENT = 5231
	WM_APP_MANUAL   = 0x8030
	manualOfferTag  = "NXD1-DAVET:"
	manualAnswerTag = "NXD1-YANIT:"
)

var (
	manualOpBtn, manualAgentBtn uintptr
	manualMu                    sync.Mutex
	manualBlob                  string // blob waiting to be shown on the GUI thread
	manualPeer                  *webrtcpeer.Peer
)

func packBlob(tag string, payload []byte) string {
	var buf bytes.Buffer
	w, _ := flate.NewWriter(&buf, flate.BestCompression)
	w.Write(payload)
	w.Close()
	return tag + base64.RawURLEncoding.EncodeToString(buf.Bytes())
}

func unpackBlob(tag, s string) ([]byte, bool) {
	s = strings.Join(strings.Fields(s), "") // WhatsApp may wrap long lines
	i := strings.Index(s, tag)
	if i < 0 {
		return nil, false
	}
	raw, err := base64.RawURLEncoding.DecodeString(strings.TrimRight(s[i+len(tag):], ".,;"))
	if err != nil {
		return nil, false
	}
	b, err := io.ReadAll(io.LimitReader(flate.NewReader(bytes.NewReader(raw)), 64<<10))
	if err != nil || len(b) == 0 {
		return nil, false
	}
	return b, true
}

func iceServers() []webrtc.ICEServer {
	cfg := currentSettings()
	ice := []webrtc.ICEServer{{URLs: []string{"stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"}}}
	if u := strings.TrimSpace(cfg.TurnURL); u != "" {
		srv := webrtc.ICEServer{URLs: []string{u}}
		if strings.TrimSpace(cfg.TurnUser) != "" {
			srv.Username, srv.Credential, srv.CredentialType = cfg.TurnUser, cfg.TurnPass, webrtc.ICECredentialTypePassword
		}
		ice = append(ice, srv)
	}
	return ice
}

// newManualPeer has no trickle signaling: candidates travel inside the SDP.
func newManualPeer() (*webrtcpeer.Peer, error) {
	return webrtcpeer.NewWithConfig(true, webrtc.Configuration{ICEServers: iceServers()}, nil)
}

func sessionCtx() context.Context {
	state.mu.Lock()
	defer state.mu.Unlock()
	if state.ctx == nil {
		state.ctx, state.cancel = context.WithCancel(context.Background())
	}
	return state.ctx
}

// ---- operator ----

func manualOperatorStart() {
	defer logCrash("manualOp")
	userStopped.Store(false)
	everConnected.Store(false)
	setActiveCode("")
	setStatus("● Davet kodu hazırlanıyor (ağ adresleri toplanıyor)…")
	peer, err := newManualPeer()
	if err != nil {
		setStatus("● Bağlantı hazırlanamadı: " + err.Error())
		return
	}
	peer.SetScreenHandler(setViewerFrame)
	peer.SetControlHandler(func(msg string) { defer logCrash("control"); handleRemoteInput(peer, msg) })
	peer.SetFileHandler(func(d []byte) { defer logCrash("file"); handleRemoteFile(d) })
	if peer.CreateControl() != nil || peer.CreateFile() != nil || peer.CreateScreen() != nil {
		setStatus("● Veri kanalları açılamadı.")
		return
	}
	offer, err := peer.Offer(sessionCtx())
	if err != nil {
		setStatus("● Davet oluşturulamadı: " + err.Error())
		return
	}
	state.mu.Lock()
	state.peer = peer
	state.mu.Unlock()
	manualMu.Lock()
	manualPeer = peer
	manualBlob = packBlob(manualOfferTag, offer.Payload)
	manualMu.Unlock()
	netlogf("Sunucusuz davet oluşturuldu (%d karakter)", len(manualBlob))
	postMessage.Call(state.hwnd, WM_APP_MANUAL, 1, 0)
}

// manualOperatorShow runs on the GUI thread: hand out the invite, take the reply.
func manualOperatorShow() {
	manualMu.Lock()
	blob, peer := manualBlob, manualPeer
	manualMu.Unlock()
	if blob == "" || peer == nil {
		return
	}
	copyToClipboard(blob)
	if askYesNo("Sunucusuz Bağlantı — 1/2", "Davet kodu panoya kopyalandı.\r\n\r\nBunu karşı tarafa gönderin; o NexDesk'te 'Destek Al' > 'Davet Kodunu Yapıştır' ile girecek ve size bir YANIT kodu gönderecek.\r\n\r\nDaveti WhatsApp ile göndermek ister misiniz?") {
		openWhatsApp("NexDesk davet kodu (tamamını kopyalayın):\n" + blob)
	}
	for {
		txt, ok := promptText("Sunucusuz Bağlantı — 2/2", "Karşı tarafın gönderdiği YANIT kodunu yapıştırın:", "")
		if !ok {
			setStatus("● Sunucusuz bağlantı iptal edildi.")
			_ = peer.Close()
			return
		}
		payload, valid := unpackBlob(manualAnswerTag, txt)
		if !valid {
			if strings.Contains(txt, manualOfferTag) {
				showInfo("Bu sizin kendi davet kodunuz. Karşı tarafın gönderdiği YANIT kodunu yapıştırın.")
			} else {
				showInfo("Yanıt kodu okunamadı. Mesajın tamamını kopyaladığınızdan emin olun.")
			}
			continue
		}
		if err := peer.AddSignal(webrtcpeer.Signal{Kind: "answer", Payload: payload}); err != nil {
			showInfo("Yanıt uygulanamadı: " + err.Error())
			_ = peer.Close()
			return
		}
		break
	}
	setStatus("● Yanıt alındı — doğrudan bağlantı kuruluyor…")
	go watchPeer(peer)
}

// ---- agent ----

func manualAgentPaste() {
	txt, ok := promptText("Davet Kodunu Yapıştır", "Destek verenin gönderdiği DAVET kodunu yapıştırın:", "")
	if !ok {
		return
	}
	payload, valid := unpackBlob(manualOfferTag, txt)
	if !valid {
		showInfo("Davet kodu okunamadı. Mesajın tamamını kopyaladığınızdan emin olun.")
		return
	}
	if !askYesNo(brandName(), "Bir kişi bu davetle bilgisayarınıza bağlanmak istiyor.\r\n\r\nYalnızca TANIDIĞINIZ ve sizin çağırdığınız birine izin verin.\r\n\r\nBağlantıya izin verilsin mi?") {
		auditLog("Sunucusuz davet reddedildi")
		return
	}
	auditLog("Sunucusuz davet onaylandı")
	go manualAgentAnswer(payload)
}

func manualAgentAnswer(offer []byte) {
	defer logCrash("manualAgent")
	userStopped.Store(false)
	everConnected.Store(false)
	setStatus("● Yanıt kodu hazırlanıyor…")
	peer, err := newManualPeer()
	if err != nil {
		setStatus("● Bağlantı hazırlanamadı: " + err.Error())
		return
	}
	peer.SetControlHandler(func(msg string) { defer logCrash("control"); handleRemoteInput(peer, msg) })
	peer.SetFileHandler(func(d []byte) { defer logCrash("file"); handleRemoteFile(d) })
	ctx := sessionCtx()
	answer, err := peer.AcceptOffer(ctx, webrtcpeer.Signal{Kind: "offer", Payload: offer})
	if err != nil {
		setStatus("● Davet işlenemedi: " + err.Error())
		_ = peer.Close()
		return
	}
	state.mu.Lock()
	state.peer = peer
	state.mu.Unlock()
	startCapture(peer, ctx)
	go watchPeer(peer)
	manualMu.Lock()
	manualBlob = packBlob(manualAnswerTag, answer.Payload)
	manualMu.Unlock()
	postMessage.Call(state.hwnd, WM_APP_MANUAL, 2, 0)
}

func manualAgentShow() {
	manualMu.Lock()
	blob := manualBlob
	manualMu.Unlock()
	if blob == "" {
		return
	}
	copyToClipboard(blob)
	setStatus("● Yanıt kodu panoya kopyalandı — destek verene gönderin.")
	if askYesNo("Yanıt Kodu", "YANIT kodu panoya kopyalandı.\r\n\r\nBunu destek veren kişiye geri gönderin; o yapıştırınca bağlantı kurulur.\r\n\r\nWhatsApp ile göndermek ister misiniz?") {
		openWhatsApp("NexDesk yanıt kodu (tamamını kopyalayın):\n" + blob)
	}
}

// ---- helpers / wiring ----

func askYesNo(title, text string) bool {
	r, _, _ := messageBox.Call(state.hwnd, uintptr(unsafe.Pointer(utf16ptr(text))), uintptr(unsafe.Pointer(utf16ptr(title))), 0x00000004|0x00000020)
	return r == 6
}

func showInfo(text string) {
	messageBox.Call(state.hwnd, uintptr(unsafe.Pointer(utf16ptr(text))), uintptr(unsafe.Pointer(utf16ptr(brandName()))), 0x00000040)
}

func openWhatsApp(msg string) {
	link := "https://wa.me/?text=" + url.QueryEscape(msg)
	shellExecuteW.Call(0, uintptr(unsafe.Pointer(utf16ptr("open"))), uintptr(unsafe.Pointer(utf16ptr(link))), 0, 0, 1)
}

func layoutManualButtons(mode int, connected bool) {
	if manualOpBtn == 0 && (mode == 1 || mode == 2) {
		manualOpBtn = createControl(state.hwnd, "BUTTON", "Sunucusuz Bağlan (davet kodu)", 0x00000001, 0, 0, 10, 10, ID_MANUAL_OP)
		manualAgentBtn = createControl(state.hwnd, "BUTTON", "Davet Kodunu Yapıştır", 0x00000001, 0, 0, 10, 10, ID_MANUAL_AGENT)
	}
	moveControl(manualOpBtn, contentX+156, 470, 290, 46, mode == 2 && !connected)
	moveControl(manualAgentBtn, contentX+598, 574, 210, 46, mode == 1 && !connected && !capturing.Load())
}

func onManualCommand(id int) bool {
	switch id {
	case ID_MANUAL_OP:
		go manualOperatorStart()
	case ID_MANUAL_AGENT:
		manualAgentPaste()
	default:
		return false
	}
	return true
}
