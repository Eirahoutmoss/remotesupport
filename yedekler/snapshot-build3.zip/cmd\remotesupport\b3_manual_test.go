//go:build windows

package main

import (
	"context"
	"testing"
	"time"

	webrtcpeer "github.com/eirahoutmoss/remotesupport/client/webrtc"
	"github.com/pion/webrtc/v4"
)

func TestManualBlobRoundTrip(t *testing.T) {
	in := []byte(`{"type":"offer","sdp":"v=0\r\no=- 1 2 IN IP4 0.0.0.0\r\na=candidate:1 1 udp 2130706431 192.168.1.5 50000 typ host\r\n"}`)
	blob := packBlob(manualOfferTag, in)
	// WhatsApp-style line wrapping and surrounding text must not matter.
	wrapped := "NexDesk davet kodu:\n" + blob[:20] + "\n" + blob[20:] + " "
	out, ok := unpackBlob(manualOfferTag, wrapped)
	if !ok || string(out) != string(in) {
		t.Fatalf("round trip failed: %v %q", ok, out)
	}
	if _, ok := unpackBlob(manualAnswerTag, blob); ok {
		t.Fatal("offer accepted as answer")
	}
}

func TestManualHandshakeConnects(t *testing.T) {
	op, err := newManualPeer()
	if err != nil {
		t.Fatal(err)
	}
	defer op.Close()
	ag, err := newManualPeer()
	if err != nil {
		t.Fatal(err)
	}
	defer ag.Close()
	if err := op.CreateControl(); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	offer, err := op.Offer(ctx)
	if err != nil {
		t.Fatal(err)
	}
	offerIn, _ := unpackBlob(manualOfferTag, packBlob(manualOfferTag, offer.Payload))
	answer, err := ag.AcceptOffer(ctx, webrtcpeer.Signal{Kind: "offer", Payload: offerIn})
	if err != nil {
		t.Fatal(err)
	}
	answerIn, _ := unpackBlob(manualAnswerTag, packBlob(manualAnswerTag, answer.Payload))
	if err := op.AddSignal(webrtcpeer.Signal{Kind: "answer", Payload: answerIn}); err != nil {
		t.Fatal(err)
	}
	for ctx.Err() == nil {
		if op.ConnectionState() == webrtc.PeerConnectionStateConnected && ag.ConnectionState() == webrtc.PeerConnectionStateConnected {
			t.Logf("connected; invite %d chars, reply %d chars", len(packBlob(manualOfferTag, offer.Payload)), len(packBlob(manualAnswerTag, answer.Payload)))
			return
		}
		time.Sleep(100 * time.Millisecond)
	}
	t.Fatal("peers did not connect")
}
